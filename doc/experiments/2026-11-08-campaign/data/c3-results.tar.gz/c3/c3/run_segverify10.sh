#!/bin/bash
set -u

OUT=/srv/ax-data/c3/segverify10-20261107
PARTS=$OUT/parts
DEST=/mnt/brewfs-c3/base
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
CHECKER=/srv/ax-data/c3/verify10.py
MERGER=/srv/ax-data/c3/verify_results.py
LOG=$OUT/run.log
REMOTES=$OUT/remounts.tsv
WORKERS=${WORKERS:-4}
RSS_LIMIT_MB=${RSS_LIMIT_MB:-3072}
RESUME=${RESUME:-0}
START_SEGMENT=${START_SEGMENT:-1}
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)
TOTAL_START=$(date +%s)
CURRENT_PID=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
MAX_RSS=0

if [ -e "$OUT" ] && [ "$RESUME" != 1 ]; then
  echo "refusing to overwrite $OUT" >&2
  exit 1
fi
mkdir -p "$PARTS"
if [ "$RESUME" != 1 ]; then
  : > "$LOG"
  printf 'seq\told_pid\tnew_pid\tbaseline_rss_mb\n' > "$REMOTES"
fi

log() {
  echo "$(date -u +%FT%TZ) $*" | tee -a "$LOG"
}

rss_mb() {
  ps -C brewfs-patched -o rss= --no-headers 2>/dev/null |
    awk '{sum += $1} END {printf "%.0f", sum / 1024}'
}

mount_fresh() {
  local reason=$1 old new i
  old=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 30); do
    [ "$(pgrep -fc brewfs-patched || true)" = 0 ] && break
    sleep 1
  done
  if [ "$(pgrep -fc brewfs-patched || true)" != 0 ]; then
    log "REMOUNT_FAIL reason=$reason still_running=$(pgrep -fc brewfs-patched || true)"
    return 1
  fi
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! timeout 5 ls "$DEST" >/dev/null 2>&1; then
    timeout 30 rm -rf "$DEST" 2>/dev/null || true
  fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" \
    AWS_DEFAULT_REGION=us-east-1 nohup "$BIN" mount --privileged \
    --config "$CFG" "$DEST" </dev/null >> "$OUT/mount.log" 2>&1 &
  for i in $(seq 1 60); do
    mountpoint -q "$DEST" && break
    sleep 1
  done
  new=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  if ! mountpoint -q "$DEST" || [ -z "$new" ]; then
    log "REMOUNT_FAIL reason=$reason not_mounted old=$old new=${new:-none}"
    return 1
  fi
  if [ -n "$old" ] && [ "$new" = "$old" ]; then
    log "REMOUNT_FAIL reason=$reason pid_not_changed=$new"
    return 1
  fi
  if ! timeout 30 ls "$DEST/small" >/dev/null 2>&1; then
    log "REMOUNT_FAIL reason=$reason namespace_unreadable new=$new"
    return 1
  fi
  if ! timeout 30 head -c 16 "$DEST/small/d0000/f0000000" >/dev/null 2>&1; then
    log "REMOUNT_FAIL reason=$reason read_probe_failed new=$new"
    return 1
  fi
  CURRENT_PID=$new
  local base_rss
  base_rss=$(rss_mb)
  printf '%s\t%s\t%s\t%s\n' "$reason" "${old:-none}" "$new" "$base_rss" >> "$REMOTES"
  log "REMOUNT_OK reason=$reason old=${old:-none} new=$new baseline_rss_mb=$base_rss"
}

counts=(103 103 103 103 102 102 102 102 102 102)
start=0
for ((prior = 0; prior < START_SEGMENT - 1; prior++)); do
  start=$((start + counts[prior]))
done
log "SEGVERIFY10_START workers=$WORKERS rss_limit_mb=$RSS_LIMIT_MB resume=$RESUME start_segment=$START_SEGMENT"

if [ "$RESUME" != 1 ]; then
  if ! mount_fresh inventory; then
    log "SEGVERIFY10_FAIL inventory_remount"
    exit 2
  fi
  if ! python3 "$CHECKER" --root "$DEST" --inventory "$OUT/namespace-root.json" \
    --inventory-only >> "$LOG" 2>&1; then
    log "SEGVERIFY10_FAIL namespace_inventory"
    exit 2
  fi
fi

for seg_index in $(seq $((START_SEGMENT - 1)) 9); do
  seg_number=$((seg_index + 1))
  printf -v seg_name 'segment-%02d' "$seg_number"
  count=${counts[$seg_index]}
  seg_dirs=$PARTS/$seg_name.dirs
  : > "$seg_dirs"
  for ((d = start; d < start + count; d++)); do
    printf 'd%04d\n' "$d" >> "$seg_dirs"
  done
  start=$((start + count))
  chunk_size=$(( (count + 2) / 3 ))
  part_number=0
  seg_start=$(date +%s)
  log "SEGMENT_START $seg_name dirs=$count chunk_size=$chunk_size"
  for ((offset = 0; offset < count; offset += chunk_size)); do
    part_number=$((part_number + 1))
    printf -v part_name '%s-part-%d' "$seg_name" "$part_number"
    part_dirs=$PARTS/$part_name.dirs
    part_json=$PARTS/$part_name.json
    part_meta=$PARTS/$part_name.meta.json
    part_log=$PARTS/$part_name.log
    : > "$part_dirs"
    for ((j = offset; j < offset + chunk_size && j < count; j++)); do
      sed -n "$((j + 1))p" "$seg_dirs" >> "$part_dirs"
    done
    if ! mount_fresh "$part_name"; then
      log "SEGVERIFY10_FAIL mount before $part_name"
      exit 3
    fi
    old_pid=$(tail -n 1 "$REMOTES" | cut -f2)
    new_pid=$(tail -n 1 "$REMOTES" | cut -f3)
    start_epoch=$(date +%s)
    timeout 900 python3 "$CHECKER" --root "$DEST" --dirs-file "$part_dirs" \
      --output "$part_json" --workers "$WORKERS" > "$part_log" 2>&1 &
    checker_pid=$!
    part_peak=0
    while kill -0 "$checker_pid" 2>/dev/null; do
      sample=$(rss_mb)
      [ "${sample:-0}" -gt "$part_peak" ] && part_peak=$sample
      [ "${sample:-0}" -gt "$MAX_RSS" ] && MAX_RSS=$sample
      if [ "${sample:-0}" -gt "$RSS_LIMIT_MB" ]; then
        log "RSS_LIMIT_EXCEEDED part=$part_name rss_mb=$sample limit=$RSS_LIMIT_MB"
        kill -9 "$checker_pid" 2>/dev/null || true
        break
      fi
      sleep 0.5
    done
    wait "$checker_pid"
    rc=$?
    end_epoch=$(date +%s)
    final_sample=$(rss_mb)
    [ "${final_sample:-0}" -gt "$part_peak" ] && part_peak=$final_sample
    [ "${final_sample:-0}" -gt "$MAX_RSS" ] && MAX_RSS=$final_sample
    printf '{"part":"%s","rss_peak_mb":%s,"mount_old_pid":"%s","mount_new_pid":"%s","runner_wall_seconds":%s}\n' \
      "$part_name" "${part_peak:-0}" "${old_pid:-none}" "${new_pid:-none}" "$((end_epoch - start_epoch))" > "$part_meta"
    if [ "$rc" != 0 ] || [ ! -s "$part_json" ]; then
      log "PART_FAIL $part_name rc=$rc rss_peak_mb=$part_peak log=$(tail -1 "$part_log" 2>/dev/null)"
      mount_fresh "abort-$part_name" || true
      exit 4
    fi
    log "PART_PASS $part_name dirs=$(wc -l < "$part_dirs") rss_peak_mb=$part_peak wall_seconds=$((end_epoch - start_epoch))"
  done
  if ! python3 "$MERGER" merge --parts-dir "$PARTS" --segment "$seg_name" \
    --output "$OUT/$seg_name.json" >> "$LOG" 2>&1; then
    log "SEGVERIFY10_FAIL merge $seg_name"
    exit 5
  fi
  seg_end=$(date +%s)
  log "SEGMENT_DONE $seg_name wall_seconds=$((seg_end - seg_start))"
done

TOTAL_END=$(date +%s)
if ! python3 "$MERGER" final --outdir "$OUT" \
  --output "$OUT/verify-base-brew-segmented.json" \
  --total-wall-seconds "$((TOTAL_END - TOTAL_START))" >> "$LOG" 2>&1; then
  log "SEGVERIFY10_FAIL final_aggregate"
  exit 6
fi
log "SEGVERIFY10_DONE total_wall_seconds=$((TOTAL_END - TOTAL_START)) max_rss_mb=$MAX_RSS"
