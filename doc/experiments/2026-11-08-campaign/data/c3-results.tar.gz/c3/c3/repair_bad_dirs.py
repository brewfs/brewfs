#!/usr/bin/env python3
"""Recopy the three known-stale BrewFS directories and verify every file by SHA-256."""

import hashlib
import json
import os
import shutil
import time
from concurrent.futures import ThreadPoolExecutor

SRC = "/srv/ax-data/c3/source/small"
DST = "/mnt/brewfs-c3/base/small"
DIRS = ("d0132", "d0133", "d0371")
OUT = "/srv/ax-data/c3/badfix-20261107"
WORKERS = 8


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            block = handle.read(1 << 16)
            if not block:
                return digest.hexdigest()
            digest.update(block)


def copy_one(item):
    directory, name = item
    source = os.path.join(SRC, directory, name)
    target = os.path.join(DST, directory, name)
    try:
        shutil.copyfile(source, target)
        return directory, name, None
    except OSError as error:
        return directory, name, f"copy_error: {error}"


def verify_one(item):
    directory, name = item
    source = os.path.join(SRC, directory, name)
    target = os.path.join(DST, directory, name)
    try:
        source_size = os.stat(source).st_size
        target_size = os.stat(target).st_size
        if source_size != 4096 or target_size != 4096:
            return ({
                "dir": directory,
                "name": name,
                "reason": "size_mismatch",
                "source_size": source_size,
                "target_size": target_size,
            }, None)
        source_sha = sha256(source)
        target_sha = sha256(target)
        if source_sha != target_sha:
            return ({
                "dir": directory,
                "name": name,
                "reason": "sha_mismatch",
                "source_sha256": source_sha,
                "target_sha256": target_sha,
            }, None)
        return None, (
            f"{directory}\t{name}\t{source_sha}\t{target_sha}\tPASS\n"
        )
    except OSError as error:
        return (
            {"dir": directory, "name": name, "reason": f"io_error: {error}"},
            None,
        )


def main():
    started = time.time()
    os.makedirs(OUT, exist_ok=False)
    items = []
    for directory in DIRS:
        names = sorted(os.listdir(os.path.join(SRC, directory)))
        if len(names) != 977:
            raise SystemExit(f"{directory}: expected 977 source files, found {len(names)}")
        items.extend((directory, name) for name in names)

    copy_errors = []
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        for directory, name, error in pool.map(copy_one, items, chunksize=32):
            if error:
                copy_errors.append(
                    {"dir": directory, "name": name, "reason": error}
                )
    os.sync()

    mismatches = []
    rows = []
    if not copy_errors:
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            for mismatch, row in pool.map(verify_one, items, chunksize=32):
                if mismatch:
                    mismatches.append(mismatch)
                if row:
                    rows.append(row)

    passed = not copy_errors and not mismatches and len(items) == 2931
    result = {
        "completed": True,
        "passed": passed,
        "dirs": list(DIRS),
        "files_checked": len(items),
        "bytes_checked": len(items) * 4096,
        "copy_errors": copy_errors,
        "mismatches": mismatches,
        "wall_seconds": round(time.time() - started, 3),
    }
    with open(os.path.join(OUT, "repair-bad-dirs.json"), "w") as handle:
        json.dump(result, handle, indent=2)
    with open(os.path.join(OUT, "repair-bad-dirs.tsv"), "w") as handle:
        handle.write("dir\tname\tsource_sha256\ttarget_sha256\tstatus\n")
        handle.writelines(rows)
    print(json.dumps(result))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
