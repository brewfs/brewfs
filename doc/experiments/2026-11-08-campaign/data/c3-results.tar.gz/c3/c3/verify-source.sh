#!/bin/bash
set -e
/srv/ax-data/artifacts/bin/smallfiles verify-base \
  --root /srv/ax-data/c3/source \
  --output /srv/ax-data/c3/source-verify \
  --files 1000000 > /srv/ax-data/c3/verify-source.out 2>&1
echo VERIFY_DONE >> /srv/ax-data/c3/verify-source.out
