#!/bin/bash
set -u
SRC=/srv/ax-data/c3/source/small
DEST=/mnt/brewfs-c3/base
LOG=/srv/ax-data/c3/import-brew-chunked2.log
CSV=/srv/ax-data/c3/import-brew-chunked2.csv
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)
CHUNK=${CHUNK:-256}
JOBS=${JOBS:-8}

mount_brew() {
  mountpoint -q "$DEST" && return 0
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" \
    </dev/null >> /srv/ax-data/c3/brewfs-c3-mount-chunk2.log 2>&1 &
  for i in $(seq 1 30); do sleep 1; mountpoint -q "$DEST" && return 0; done
  return 1
}
unmount_brew() {
  fusermount3 -uz "$DEST" 2>/dev/null || umount -l "$DEST" 2>/dev/null || true
  pkill -f 'brewfs-patched mount' 2>/dev/null || true
  sleep 2
}

echo "chunk,dirs_start,dirs_end,files_done,elapsed_s,rss_mb,total_files" > "$CSV"
echo "IMPORT2_START $(date -u +%FT%TZ) chunk=$CHUNK jobs=$JOBS" > "$LOG"

ALL=$(ls "$SRC" | sort)
TOTAL=${#ALL}
TOTAL_FILES=0
START_ALL=$(date +%s)
mount_brew || { echo "MOUNT_FAILED" >> "$LOG"; exit 1; }

IDX=0
for ((i=0; i<TOTAL; i+=CHUNK)); do
  IDX=$((IDX+1))
  BATCH=$(echo "$ALL" | sed -n "$((i+1)),$((i+CHUNK))p")
  START=$(date +%s)
  N_BEFORE=$TOTAL_FILES
  # 批内并行：把 BATCH 拆成 JOBS 份
  echo "$BATCH" | split -n r/$JOBS - /tmp/imp2-part.
  PIDS=""
  for p in /tmp/imp2-part.*; do
    (
      while read -r d; do
        [ -n "$d" ] || continue
        if [ -d "$DEST/$d" ] && [ "$(find "$DEST/$d" -maxdepth 1 -type f 2>/dev/null | wc -l)" -ge 1000 ]; then
          continue
        fi
        cp -a "$SRC/$d" "$DEST/" 2>>/srv/ax-data/c3/import-brew-chunked2.err
      done < "$p"
    ) &
    PIDS="$PIDS $!"
  done
  wait $PIDS
  rm -f /tmp/imp2-part.*
  END=$(date +%s)
  HAVE=$(ls -1 "$DEST" 2>/dev/null | wc -l)
  TOTAL_FILES=$((HAVE*1000))
  RSS=$(ps -C brewfs-patched -o rss= --no-headers 2>/dev/null | awk '{s+=$1} END{printf "%d", s/1024}')
  echo "$IDX,$((i+1)),$((i+CHUNK)),$((TOTAL_FILES-N_BEFORE)),$((END-START)),${RSS:-0},$TOTAL_FILES" >> "$CSV"
  echo "chunk=$IDX dirs=$HAVE files=$TOTAL_FILES rss=${RSS}MB elapsed=$((END-START))s" >> "$LOG"
  unmount_brew
  mount_brew || { echo "REMOUNT_FAILED chunk=$IDX" >> "$LOG"; exit 1; }
done

END_ALL=$(date +%s)
echo "IMPORT2_DONE elapsed=$((END_ALL-START_ALL))s dirs=$(ls -1 "$DEST" | wc -l) $(date -u +%FT%TZ)" >> "$LOG"
