#!/bin/bash
set -u
BIN=/srv/ax-data/artifacts/bin/smallfiles
BASE=/mnt/brewfs-c3/base/small
WS=/mnt/brewfs-c3/ws-brew
OUT=/srv/ax-data/c3/pilot-brew-20261107
rm -rf "$OUT" 2>/dev/null; mkdir -p "$OUT"
echo "PILOT_START $(date -u +%FT%TZ)" > "$OUT/pilot.log"
# 用 1024 个目录 + 每目录独立，pilot 直接在 base 上跑只读+写：smallfiles run 需要独立 workspace
# 先尝试 clone（BrewFS 无 clone，则用 rsync 物化到 ws）
mkdir -p "$WS"
if [ ! -d "$WS/d0000" ]; then
  echo "materialize ws from base $(date -u +%FT%TZ)" >> "$OUT/pilot.log"
  cp -a "$BASE"/d0[0-1]*  "$WS"/ 2>>"$OUT/pilot.log" || true
fi
echo "ws dirs=$(ls -1 $WS 2>/dev/null | wc -l)" >> "$OUT/pilot.log"
"$BIN" run --root "$WS" --output "$OUT/run" \
  --files 1000000 --hot-files 1024 --workers 8 \
  --read-ops 8192 --cow-files 256 --write-ops 256 --mixed-ops 1024 \
  --seed 9173 --workspace 1 > "$OUT/run.out" 2>&1
echo "RUN_EXIT=$?" >> "$OUT/pilot.log"
"$BIN" verify-touched --root "$WS" --output "$OUT/verify" \
  --state "$OUT/run/expected-touched.tsv" > "$OUT/verify.out" 2>&1
echo "VERIFY_EXIT=$?" >> "$OUT/pilot.log"
"$BIN" verify-touched --root "$BASE" --output "$OUT/base" \
  --state "$OUT/run/expected-touched.tsv" --expect-base 1 > "$OUT/base.out" 2>&1
echo "BASE_EXIT=$?" >> "$OUT/pilot.log"
echo "PILOT_DONE $(date -u +%FT%TZ)" >> "$OUT/pilot.log"
