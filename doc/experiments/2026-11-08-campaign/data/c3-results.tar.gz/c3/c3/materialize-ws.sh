#!/bin/bash
set -u
BASE=/mnt/brewfs-c3/base/small
WS=/mnt/brewfs-c3/ws-brew
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access); SK=$(cat /etc/ax-c1/rustfs-secret)
LOG=/srv/ax-data/c3/materialize-ws.log
DEST=/mnt/brewfs-c3/base
CHUNK=${CHUNK:-256}
JOBS=${JOBS:-8}
mkdir -p "$WS"
: > "$LOG"
echo "MATERIALIZE_START $(date -u +%FT%TZ) chunk=$CHUNK" >> "$LOG"

remount() {
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 20); do [ "$(pgrep -fc brewfs-patched || echo 0)" = "0" ] && break; sleep 1; done
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! ls "$DEST" >/dev/null 2>&1; then rm -rf "$DEST" 2>/dev/null || true; fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" </dev/null >> /srv/ax-data/c3/mount-mat.log 2>&1 &
  for i in $(seq 1 40); do sleep 1; mountpoint -q "$DEST" && break; done
  timeout 10 ls "$DEST/small" >/dev/null 2>&1 || return 1
  return 0
}

ALL=$(ls "$BASE" | sort)
i=0; n=0
for d in $ALL; do
  n=$((n+1))
  if [ $(( (n-1) % CHUNK )) -eq 0 ]; then
    remount || { echo "REMOUNT_FAILED at $d" >> "$LOG"; exit 1; }
    echo "remounted before $d (done=$(ls -1 $WS | wc -l))" >> "$LOG"
  fi
  [ -d "$WS/$d" ] || cp -a "$BASE/$d" "$WS/" 2>>/srv/ax-data/c3/materialize-ws.err
done
echo "MATERIALIZE_DONE $(date -u +%FT%TZ) dirs=$(ls -1 $WS | wc -l) files=$(find $WS -type f | wc -l)" >> "$LOG"
