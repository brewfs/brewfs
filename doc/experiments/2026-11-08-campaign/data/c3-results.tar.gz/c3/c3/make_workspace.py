#!/usr/bin/env python3
"""Create a metadata-only BrewFS workspace by hardlinking base directories."""

import argparse
import json
import os
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

BASE = "/mnt/brewfs-c3/base"
WS = "/mnt/brewfs-c3/base/ws-c3-20261107"
DONE = "/srv/ax-data/c3/brew-workspace-build-20261107/done"
TOTAL_FILES = 1_000_000


def expected_count(directory_index):
    return len(range(directory_index, TOTAL_FILES, 1024))


def build_one(directory_index):
    name = f"d{directory_index:04d}"
    source = os.path.join(BASE, "small", name)
    target = os.path.join(WS, "small", name)
    marker = os.path.join(DONE, name)
    if os.path.exists(marker) and os.path.isdir(target):
        return {"dir": name, "status": "skipped", "files": expected_count(directory_index)}
    if os.path.exists(target):
        shutil.rmtree(target)
    result = subprocess.run(
        ["cp", "-rl", source, os.path.join(WS, "small") + "/"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        return {
            "dir": name,
            "status": "error",
            "reason": f"cp_rc_{result.returncode}: {result.stderr.strip()[-400:]}",
        }
    actual = len(os.listdir(target))
    expected = expected_count(directory_index)
    if actual != expected:
        return {
            "dir": name,
            "status": "error",
            "reason": f"file_count expected={expected} actual={actual}",
        }
    with open(marker, "x") as handle:
        handle.write(f"{name}\t{actual}\n")
    return {"dir": name, "status": "created", "files": actual}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, required=True)
    parser.add_argument("--end", type=int, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    os.makedirs(DONE, exist_ok=True)
    os.makedirs(os.path.join(WS, "small"), exist_ok=True)
    started = time.time()
    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(build_one, range(args.start, args.end)):
            results.append(result)
            print(json.dumps(result), flush=True)
    errors = [result for result in results if result["status"] == "error"]
    summary = {
        "start": args.start,
        "end": args.end,
        "dirs": len(results),
        "created": sum(result["status"] == "created" for result in results),
        "skipped": sum(result["status"] == "skipped" for result in results),
        "errors": errors,
        "files": sum(result.get("files", 0) for result in results if result["status"] != "error"),
        "wall_seconds": round(time.time() - started, 3),
        "status": "PASS" if not errors else "FAIL",
    }
    with open(args.output, "w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
