#!/bin/bash
set -e
while ! grep -q '^VERIFY_DONE$' /srv/ax-data/c3/juicefs-base-par-verify.out 2>/dev/null; do sleep 30; done
/srv/ax-data/c3/run-c3-juice-pilot.sh > /srv/ax-data/c3/pilot-juice.driver 2>&1
