#!/bin/bash
set -e
while ! grep -q '^PARALLEL_IMPORT_DONE$' /srv/ax-data/c3/parallel-import-a.log 2>/dev/null; do sleep 30; done
/srv/ax-data/artifacts/bin/smallfiles verify-base --root /mnt/juicefs-c3/base-par --output /srv/ax-data/c3/juicefs-base-par-verify --files 1000000 > /srv/ax-data/c3/juicefs-base-par-verify.out 2>&1
echo VERIFY_DONE >> /srv/ax-data/c3/juicefs-base-par-verify.out
