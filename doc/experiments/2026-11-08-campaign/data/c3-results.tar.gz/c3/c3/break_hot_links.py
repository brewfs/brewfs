#!/usr/bin/env python3
"""Break the 1024 workspace hardlinks that smallfiles may write, preserving base."""

import hashlib
import json
import os
import struct
import time
from concurrent.futures import ThreadPoolExecutor

BASE = "/mnt/brewfs-c3/base"
WS = "/mnt/brewfs-c3/base/ws-c3-20261107"
OUT = "/srv/ax-data/c3/brew-workspace-build-20261107"
SEED = 9173
HOT_FILES = 1024
TOTAL_FILES = 1_000_000
PAYLOAD_BYTES = 4096
MASK = (1 << 64) - 1


def splitmix64(state):
    state = (state + 0x9E3779B97F4A7C15) & MASK
    value = state
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
    value ^= value >> 31
    return state, value


def bounded(state, limit):
    threshold = ((-limit) & MASK) % limit
    while True:
        state, value = splitmix64(state)
        if value >= threshold:
            return state, value % limit


def payload(index):
    state = index
    words = []
    for _ in range(PAYLOAD_BYTES // 8):
        state, value = splitmix64(state)
        words.append(value)
    return struct.pack("<512Q", *words)


def hot_set():
    state = SEED
    seen = set()
    result = []
    while len(result) < HOT_FILES:
        state, index = bounded(state, TOTAL_FILES)
        if index not in seen:
            seen.add(index)
            result.append(index)
    return result


def path(root, index):
    return os.path.join(root, "small", f"d{index % 1024:04d}", f"f{index:07d}")


def break_one(index):
    source = path(BASE, index)
    target = path(WS, index)
    expected = payload(index)
    temporary = target + ".cow-tmp"
    try:
        with open(source, "rb") as handle:
            source_bytes = handle.read()
        if source_bytes != expected:
            return {
                "index": index,
                "reason": "base_payload_mismatch",
                "size": len(source_bytes),
            }
        if os.stat(source).st_ino == os.stat(target).st_ino:
            descriptor = os.open(
                temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644
            )
            try:
                os.write(descriptor, expected)
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            os.replace(temporary, target)
        elif not os.path.exists(target):
            return {"index": index, "reason": "workspace_file_missing"}
        with open(target, "rb") as handle:
            actual = handle.read()
        if actual != expected:
            return {
                "index": index,
                "reason": "workspace_payload_mismatch",
                "size": len(actual),
            }
        source_inode = os.stat(source).st_ino
        target_inode = os.stat(target).st_ino
        if source_inode == target_inode:
            return {"index": index, "reason": "hardlink_not_broken"}
        with open(source, "rb") as handle:
            if handle.read() != expected:
                return {"index": index, "reason": "base_changed"}
        return None
    except OSError as error:
        return {"index": index, "reason": f"io_error: {error}"}


def main():
    os.makedirs(OUT, exist_ok=True)
    indices = hot_set()
    with open(os.path.join(OUT, "hot-set.txt"), "w") as handle:
        for index in indices:
            handle.write(f"{index}\n")
    started = time.time()
    failures = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        for failure in pool.map(break_one, indices):
            if failure:
                failures.append(failure)
    result = {
        "completed": True,
        "passed": not failures,
        "hot_files": len(indices),
        "broken_links": len(indices) - len(failures),
        "failures": failures,
        "wall_seconds": round(time.time() - started, 3),
    }
    with open(os.path.join(OUT, "break-hot-links.json"), "w") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps(result))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
