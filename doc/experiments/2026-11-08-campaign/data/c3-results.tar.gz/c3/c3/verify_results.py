#!/usr/bin/env python3
"""Merge bounded verifier chunks into segments and a final report."""

import argparse
import glob
import json
import os

EXPECTED_DIRS = {f"d{index:04d}" for index in range(1024)}
TOTAL_FILES = 1_000_000
PAYLOAD_BYTES = 4096


def load_json(path):
    with open(path) as handle:
        return json.load(handle)


def merge_segment(parts_dir, segment, output):
    part_files = sorted(
        path
        for path in glob.glob(os.path.join(parts_dir, f"{segment}-part-*.json"))
        if not path.endswith(".meta.json")
    )
    if not part_files:
        raise SystemExit(f"no parts for {segment}")
    dirs = []
    mismatches = []
    chunks = []
    checked = 0
    passed = 0
    wall_seconds = 0.0
    rss_peak_mb = 0
    for part_file in part_files:
        part = load_json(part_file)
        meta_file = part_file[:-5] + ".meta.json"
        meta = load_json(meta_file) if os.path.exists(meta_file) else {}
        dirs.extend(part["dirs"])
        mismatches.extend(part.get("mismatches", []))
        checked += part["checked"]
        passed += part["passed"]
        wall_seconds += part.get("wall_seconds", 0.0)
        rss_peak_mb = max(rss_peak_mb, int(meta.get("rss_peak_mb", 0)))
        chunks.append(
            {
                "part": part.get("segment", os.path.basename(part_file)[:-5]),
                "dirs": part.get("dir_count", len(part["dirs"])),
                "checked": part.get("checked", 0),
                "passed": part.get("passed", 0),
                "failed": part.get("failed", 0),
                "wall_seconds": part.get("wall_seconds", 0.0),
                "rss_peak_mb": meta.get("rss_peak_mb"),
                "mount_old_pid": meta.get("mount_old_pid"),
                "mount_new_pid": meta.get("mount_new_pid"),
            }
        )
    if len(dirs) != len(set(dirs)):
        raise SystemExit(f"duplicate directories inside {segment}")
    result = {
        "segment": segment,
        "dirs": dirs,
        "dir_count": len(dirs),
        "checked": checked,
        "passed": passed,
        "failed": checked - passed,
        "bytes": checked * PAYLOAD_BYTES,
        "mismatches": mismatches,
        "status": "PASS" if checked == passed and not mismatches else "FAIL",
        "wall_seconds": round(wall_seconds, 3),
        "rss_peak_mb": rss_peak_mb,
        "remounts": len(chunks),
        "chunks": chunks,
    }
    with open(output, "w") as handle:
        json.dump(result, handle, indent=2)
    print(json.dumps({key: result[key] for key in ("segment", "dir_count", "checked", "passed", "failed", "wall_seconds", "rss_peak_mb", "remounts", "status")}))


def final_report(outdir, output, total_wall_seconds=None):
    segment_files = sorted(glob.glob(os.path.join(outdir, "segment-??.json")))
    segment_reports = [load_json(path) for path in segment_files]
    dirs = []
    mismatches = []
    files = 0
    passed_files = 0
    wall_seconds = 0.0
    rss_peak_mb = 0
    remounts = 0
    for report in segment_reports:
        dirs.extend(report.get("dirs", []))
        mismatches.extend(report.get("mismatches", []))
        files += report.get("checked", 0)
        passed_files += report.get("passed", 0)
        wall_seconds += report.get("wall_seconds", 0.0)
        rss_peak_mb = max(rss_peak_mb, report.get("rss_peak_mb", 0))
        remounts += report.get("remounts", 0)

    duplicates = sorted({name for name in dirs if dirs.count(name) > 1})
    dir_set = set(dirs)
    expected_ok = (
        len(segment_reports) == 10
        and dir_set == EXPECTED_DIRS
        and not duplicates
        and files == TOTAL_FILES
        and passed_files == TOTAL_FILES
        and not mismatches
    )
    summary = {
        "completed": len(segment_reports) == 10,
        "passed": expected_ok,
        "files": files,
        "passed_files": passed_files,
        "bytes": files * PAYLOAD_BYTES,
        "expected_files": TOTAL_FILES,
        "expected_bytes": TOTAL_FILES * PAYLOAD_BYTES,
        "wall_seconds": round(
            total_wall_seconds if total_wall_seconds is not None else wall_seconds,
            3,
        ),
        "verify_wall_seconds": round(wall_seconds, 3),
        "segments_run": len(segment_reports),
        "dirs_verified": len(dir_set),
        "duplicate_dirs": duplicates,
        "missing_dirs": sorted(EXPECTED_DIRS - dir_set),
        "unexpected_dirs": sorted(dir_set - EXPECTED_DIRS),
        "mismatches_total": len(mismatches),
        "mismatches": mismatches,
        "rss_peak_mb": rss_peak_mb,
        "remounts": remounts,
        "method": (
            "10 logical segments, each split into three bounded chunks; "
            "fresh BrewFS remount before every chunk; read-only direct "
            "smallfiles payload verification (4096 bytes, d#### sharding, f####### names)"
        ),
        "segments": [
            {
                "segment": report.get("segment"),
                "dirs": report.get("dir_count"),
                "files": report.get("checked"),
                "passed_files": report.get("passed"),
                "mismatches": len(report.get("mismatches", [])),
                "wall_seconds": report.get("wall_seconds"),
                "rss_peak_mb": report.get("rss_peak_mb"),
                "remounts": report.get("remounts"),
            }
            for report in segment_reports
        ],
    }
    with open(output, "w") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary))
    if not summary["passed"]:
        raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    merge = subparsers.add_parser("merge")
    merge.add_argument("--parts-dir", required=True)
    merge.add_argument("--segment", required=True)
    merge.add_argument("--output", required=True)
    final = subparsers.add_parser("final")
    final.add_argument("--outdir", required=True)
    final.add_argument("--output", required=True)
    final.add_argument("--total-wall-seconds", type=float, default=None)
    args = parser.parse_args()
    if args.command == "merge":
        merge_segment(args.parts_dir, args.segment, args.output)
    else:
        final_report(args.outdir, args.output, args.total_wall_seconds)


if __name__ == "__main__":
    main()
