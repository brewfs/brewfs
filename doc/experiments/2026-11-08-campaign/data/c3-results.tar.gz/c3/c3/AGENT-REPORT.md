
## 2026-11-07 09:48 CST — final importer takeover
- 现场接管前：source d* = 1024；done d* markers = 895（done/ 另有历史遗留 `base` 标记）；BrewFS mount 中 d* = 903。
- 旧 `import-brew-v4.sh` 仍在运行并卡在批次，原始日志/CSV 保留；本次将停止其进程并使用 `import-brew-final.sh`，不删除任何旧证据。

## 2026-11-07 10:04 CST — final importer completed
- 编排器：`/srv/ax-data/c3/import-brew-final.sh`；日志：`import-brew-final.log`；CSV：`import-brew-final.csv`。
- 完成：source `d*` = 1024；`done/d*` markers = 1024；BrewFS mount 中 `d*` directories = 1024；挂载在线。
- 本轮总耗时：547 s（2026-11-07T01:54:24Z → 02:03:31Z）；实际复制批次：chunk 8，103 directories，542 s；其余 7 个 chunk 依据 marker O(1) 跳过。
- CSV 摘要：chunks 1–7 copied=0/rss=49 MB/pid=19680→19680/ok=1；chunk 8 copied=103/elapsed=542 s/rss=9069 MB/pid=19680→21074/ok=1。
- RSS 曲线：挂载初始 49 MB；chunk 8 复制中约 1.1、2.6、3.3、4.0、4.7、5.4、6.1、6.8、7.5、8.2、8.8 GB，批末 9069 MB；未触发 >30 GB 自适应减批。
- 本轮 `Dropping an active transaction`：0（`mount.log` 中本轮增量计数）。旧 v4 日志和其它 partial/探针条目均保留。
- 根下历史探针条目 `base`、`lat-*`、`probe*` 保留；完成计数按任务源集合的 `d*` 条目统计。

## 2026-11-07 10:06 CST — first verify attempt and layout diagnosis
- 按要求首次运行 `smallfiles verify-base --root /mnt/brewfs-c3/base --output /srv/ax-data/c3/verify-base-brew-20261107 --files 1000000`；进程快速失败，日志为 `No such file or directory (os error 2)`，只生成 `started.json`。
- 根因：`smallfiles` 固定检查 `<root>/small/d0000...d1023`；历史导入脚本将 d* 放在 `<root>`，所以缺少 `<root>/small` 命名空间。失败输出保留，随后将目录重排到 `<root>/small` 后重试。

## 2026-11-07 10:11 CST — BrewFS namespace layout fixed
- 保留首次失败证据为 `/srv/ax-data/c3/verify-base-brew-20261107-failed`。
- 在 BrewFS 上创建 `/mnt/brewfs-c3/base/small`，将原根下 1024 个 `d0000..d1023` 目录逐目录 rename 到 `small/`；耗时 33 s，moved=1024，failed=0。根下历史 `base`/`lat-*`/`probe*` 条目保留。
- 现在 `base/small/d*` = 1024，准备按原命令重跑全量 verify-base。

## 2026-11-07 10:22 CST — verify attempt 2 stopped for cache control
- 第二次 verify 已进入全量读取但约 11 min 时 BrewFS RSS 达 ~10 GB 且持续线性上涨；为避免 64 GB 主机被单次校验打爆，保留该尝试并停止后重跑。
- 原 `/etc/ax-c1/brewfs-c3.yaml` 将备份为 `brewfs-c3.yaml.preverify`；临时降低 metadata open-file/read-plan cache 上限到 1024/1024，再用同一配置路径和 AWS_* 环境变量重挂。

## 2026-11-07 10:43 CST — low-cache verify attempt retained
- 低缓存重跑实际仅约 24 FUSE reads/s，无法在合理时间完成；其输出/日志将保留为 `verify-base-brew-20261107-attempt2*`。
- 恢复导入时的原始 `/etc/ax-c1/brewfs-c3.yaml`（备份 `brewfs-c3.yaml.preverify` 保留），采用原 metadata cache 以恢复已观测的吞吐；重挂后继续全量 verify。

## 2026-11-07 10:52 CST — verifier parallelization for BrewFS scale
- 原始 `smallfiles` 单线程 verify-base 在 BrewFS 上约 30 reads/s；为避免数小时等待，保留原二进制/源码备份，给 verify-base 增加有界 16-worker 并行（只分片同一组 namespace 与 `read_checked`，校验规则/结果字段不变）。`run` 与 `verify-touched` 分支不变。
- 新校验仍使用 `/srv/ax-data/artifacts/bin/smallfiles verify-base` 命令路径；原二进制记录为 `smallfiles-original`，源码记录为 `.preparallel`。

## 2026-11-07 11:03 CST — verify found stale marker / zero-length file
- 并行 verify attempt 4 在 file index `103554` 失败；对应 `d0130/f0103554` 源文件为 4096 bytes，而 BrewFS 文件为 0 bytes。marker `done/d0130` 的时间早于旧 v4 中断，证明旧导入可能在数据持久化前留下 marker。
- 保留 attempt4 输出/日志；将错误 marker 移至 `bad-markers/d0130`，修复 final importer 使数据目标固定为 `base/small/`，再补拷该目录。

## 2026-11-07 11:15 CST — default-cache parallel verify attempt retained
- 补拷 `d0130` 后并行 verify attempt5 已通过前 154k 文件，但默认 metadata cache RSS 达 11.7 GB 且增速偏高；为保证 64 GB 主机余量，保留 attempt5 并切换低 cache + 16 worker 组合做最终校验。

## 2026-11-07 11:25 CST — second stale-marker mismatch
- 最终低 cache 并行 verify attempt6 在 index `278899` 失败；`d0371/f0278899` 源为 4096 bytes、BrewFS 为 0 bytes，属于同类旧 marker/中断导入问题。
- 保留 attempt6 输出/日志；下一步低内存重挂后全量扫描 `base/small` 零长度文件，再批量修复坏目录。

## 2026-11-07 11:40 CST — switched from serial zero scan to all-error audit
- 单进程 `find -size 0` 在 FUSE 上仅约 30 stat/s，已停止并保留空/未完成扫描证据。
- 将 verifier 的并行 payload worker 改为收集全部 `read_checked` 错误后再返回，使用一次全量 16-worker audit 列出所有坏文件，再批量补拷对应目录。

## 2026-11-07 11:49 CST — all-error audit identified 3 stale files
- 全量 16-worker audit（输出 `/srv/ax-data/c3/verify-base-brew-audit-20261107`，日志保留）扫描 999,997 个文件后收集到 3 个 mismatch：indices `104580` (`d0132/f0104580`)、`108677` (`d0133/f0108677`)、`278899` (`d0371/f0278899`)；均为源 4096 bytes、BrewFS 0 bytes。
- index `103554` 的 `d0130` 已在前一轮补拷并通过 audit；本轮将批量补拷 d0132、d0133、d0371。

## 2026-11-07 16:57 CST — 完成坏文件修复、10 段 verify 与 BrewFS pilot（最终 PASS）

### 1. 为什么偏离单趟 verify-base
- 单趟 verify/audit 会让 BrewFS RSS 线性涨到 33–39 GB，曾在 64 GB a-client 上拖到 sshd 失联；本轮不能重复该风险。
- 额外标定：32 目录 / 31,264 文件、4 个并发 reader，BrewFS 峰值 1,604 MB，说明仍约 50 KB/文件的进程内累积。
- 因此采用 **10 个逻辑段**（首 4 段各 103 目录，后 6 段各 102 目录），每段再拆为 3 个有界子块（每块最多 35 目录 / 约 3.5 万文件）；**每块前都完整重挂**。这不是单次 10 个进程，而是 10 个逻辑段 × 3 个有界校验块，共 30 次 checker、31 次重挂（含一次 inventory），以满足“任何时刻 RSS ≤ 3 GB”的更高优先级约束。
- 重挂固定序列：`pkill -9 brewfs-patched mount` → 等进程归零 → `umount -l` → 死点则 `rm -rf` 重建 → 带 `AWS_*` 重挂 → 断言新 PID ≠ 旧 PID → namespace + 单文件读探针。全程 BrewFS 峰值 **1,785 MB**。

### 2. 分段校验规则与实现
- `smallfiles verify-base` 不能表达目录子集；未改 BrewFS，使用只读校验器 `/srv/ax-data/c3/verify10.py`。
- 规则与 `smallfiles verify-base` 的 version-0 规则一致：`small/` 目录集合严格为 `d0000..d1023`（1,024 个）；目录 `d####` 文件名严格为 `f{index:07d}` 且 `index % 1024 == ####`；每文件必须是 regular file、恰好 4,096 bytes，内容逐字节等于 Rust `smallfiles::payload(index,0,0)` 的 SplitMix64 结果。
- 校验器自测：源数据 `d0000..d0001` 共 1,954 文件全部 PASS；随后对 BrewFS 全量 1,000,000 文件执行。每段 JSON 在 `/srv/ax-data/c3/segverify10-20261107/segment-01..10.json`，最终汇总在 `/srv/ax-data/c3/segverify10-20261107/verify-base-brew-segmented.json`。
- 第一次 merge 时汇总器把 `*.meta.json` 误当 part，导致段 1 合并中止（校验数据本身已 PASS）；修复过滤后从段 2 续跑。原始失败日志保留，未重做段 1。

| segment | dirs | files | checker_s | 段墙钟_s | RSS 峰值 MB |
|---|---:|---:|---:|---:|---:|
| segment-01 | 103 | 100,631 | 145.059 | 156 | 1,785 |
| segment-02 | 103 | 100,631 | 127.864 | 140 | 1,778 |
| segment-03 | 103 | 100,631 | 124.724 | 136 | 1,780 |
| segment-04 | 103 | 100,631 | 129.582 | 142 | 1,782 |
| segment-05 | 102 | 99,654 | 121.931 | 134 | 1,730 |
| segment-06 | 102 | 99,614 | 126.733 | 138 | 1,723 |
| segment-07 | 102 | 99,552 | 130.482 | 142 | 1,718 |
| segment-08 | 102 | 99,552 | 128.920 | 141 | 1,724 |
| segment-09 | 102 | 99,552 | 126.054 | 137 | 1,724 |
| segment-10 | 102 | 99,552 | 131.602 | 144 | 1,728 |

- 校验总墙钟 **1,510 s**（含 merge 修复后 96 s 停点）；checker 累计 1,292.951 s；重挂 31 次；BrewFS RSS 峰值 1,785 MB。
- 最终汇总：`completed=true`、`passed=true`、`files=1,000,000`、`bytes=4,096,000,000`、`dirs_verified=1,024`、`duplicate_dirs=[]`、`missing_dirs=[]`、`unexpected_dirs=[]`、`mismatches_total=0`。

### 3. 三个坏目录修复证据
- audit 修复前原始错误：`104580 / d0132/f0104580`、`108677 / d0133/f0108677`、`278899 / d0371/f0278899`，均为源 4,096 B、BrewFS 0 B；日志 `/srv/ax-data/c3/verify-base-brew-audit-20261107.log` 与 `bad-markers/` 保留。
- 用 `/srv/ax-data/c3/repair_bad_dirs.py` 重拷 `d0132`、`d0133`、`d0371` 全部 2,931 文件并逐文件比对源/目标 SHA-256：`files_checked=2931`、`bytes_checked=12005376`、`copy_errors=0`、`mismatches=0`、`wall_seconds=14.757`，TSV 2,931 行全 PASS；BrewFS 峰值 1,298 MB。
- 证据：`/srv/ax-data/c3/badfix-20261107/repair-bad-dirs.json`、`repair-bad-dirs.tsv`、`badfix-20261107.log`。
- 此后 10 段全量校验未再发现任何缺失、尺寸或 payload mismatch。

### 4. BrewFS pilot：workspace 与结果
- BrewFS 没有 JuiceFS `clone`；为避免把 workspace 放到本地盘，在 BrewFS 内创建 `/mnt/brewfs-c3/base/ws-c3-20261107/small`，用 `cp -rl` 做 **1,000,000 个文件的 metadata-only 硬链接** workspace（完整 1,024 目录命名空间），再对 deterministic hot set 的 **1,024 个文件显式断链并写入独立 inode**。这样 run 的写只落在 hot 文件，base 保持 version 0。
- workspace 构建：32 个 chunk、1024 done markers、1,000,000 文件；随机 512 个非 hot 样本 base/ws inode 全部一致；1024/1024 hot 断链成功、0 failure；BrewFS 峰值 1,368 MB。证据 `/srv/ax-data/c3/brew-workspace-build-20261107/`。
- pilot 命令与 JuiceFS 协议一致：`smallfiles run --root <brew-ws> --output <out>/run --files 1000000 --hot-files 1024 --workers 8 --read-ops 8192 --cow-files 256 --write-ops 256 --mixed-ops 1024 --seed 9173 --workspace 1`。
- `run`：`passed=true`，**wall_seconds=8.961271029 s**，verified_reads=20,224，writes=768，read_bytes=82,837,504，write_bytes=3,145,728；BrewFS 峰值 899 MB。
- run 后重挂再校验：`verify-touched` child **PASS，256 files，2.186 s**；base `--expect-base 1` **PASS，256 files，2.060 s**。base 没有被 pilot 写污染。
- 证据：`/srv/ax-data/c3/pilot-brew-segverify-20261107/`（`pilot-summary.json`、`run/`、`verify/`、`base/`、`pilot.log`）。

### 5. 最终结论与遗留风险
- **最终 PASS**：BrewFS C3 base 1,000,000 文件 / 4,096,000,000 bytes 全量分段 verify 0 mismatch；pilot run 与 child/base verify-touched 全部 PASS。
- 风险 1：BrewFS 单挂载连续读仍有约 50 KB/文件 RSS 累积；本轮靠 35 目录级重挂压到 1.8 GB，长时间不重挂的单趟 1M verify 仍不安全。
- 风险 2：为守住 3 GB，本实现是 10 个逻辑段内的 30 个有界 checker/31 次重挂，不是字面上的 10 个单进程单趟；校验规则未降级。
- 风险 3：BrewFS 无原生 clone，workspace 用 1M 硬链接模拟 metadata-only clone；非 hot 文件 link count 增加，base 内容未变。pilot 的 `remote_durability_verified=false` 是工具字段，但 run 后重挂再 verify-touched 已验证持久化视图。
- 未触碰 `/mnt/juicefs-c2*`、`/mnt/juicefs-c3`、C2 结果、旧 attempt 或 `bad-markers`；未重启 TiKV/PD/RustFS，未 reboot。
