#!/bin/bash
set -u

OUT=/srv/ax-data/c3/pilot-brew-segverify-20261107
WS=/mnt/brewfs-c3/base/ws-c3-20261107
BASE=/mnt/brewfs-c3/base
DEST=$BASE
CFG=/etc/ax-c1/brewfs-c3.yaml
BREW=/srv/ax-data/artifacts/bin/brewfs-patched
BIN=/srv/ax-data/artifacts/bin/smallfiles
LOG=$OUT/pilot.log
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)

if [ -e "$OUT" ]; then
  echo "refusing to overwrite $OUT" >&2
  exit 1
fi
mkdir -p "$OUT"
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

log() {
  echo "$(date -u +%FT%TZ) $*"
}

rss_mb() {
  ps -C brewfs-patched -o rss= --no-headers 2>/dev/null |
    awk '{sum += $1} END {printf "%.0f", sum / 1024}'
}

mount_fresh() {
  local reason=$1 old new i
  old=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 30); do
    [ "$(pgrep -fc brewfs-patched || true)" = 0 ] && break
    sleep 1
  done
  if [ "$(pgrep -fc brewfs-patched || true)" != 0 ]; then
    log "REMOUNT_FAIL reason=$reason still_running=$(pgrep -fc brewfs-patched || true)"
    return 1
  fi
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! timeout 5 ls "$DEST" >/dev/null 2>&1; then
    timeout 30 rm -rf "$DEST" 2>/dev/null || true
  fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" \
    AWS_DEFAULT_REGION=us-east-1 nohup "$BREW" mount --privileged \
    --config "$CFG" "$DEST" </dev/null >> "$OUT/mount.log" 2>&1 &
  for i in $(seq 1 60); do
    mountpoint -q "$DEST" && break
    sleep 1
  done
  new=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  if ! mountpoint -q "$DEST" || [ -z "$new" ]; then
    log "REMOUNT_FAIL reason=$reason not_mounted old=$old new=${new:-none}"
    return 1
  fi
  if [ -n "$old" ] && [ "$new" = "$old" ]; then
    log "REMOUNT_FAIL reason=$reason pid_not_changed=$new"
    return 1
  fi
  if ! timeout 30 ls "$DEST/small" >/dev/null 2>&1; then
    log "REMOUNT_FAIL reason=$reason namespace_unreadable new=$new"
    return 1
  fi
  log "REMOUNT_OK reason=$reason old=${old:-none} new=$new baseline_rss_mb=$(rss_mb)"
}

log "PILOT_START ws=$WS"
mount_fresh before-run || exit 2
if [ "$(ls "$WS/small" | wc -l)" != 1024 ]; then
  log "WORKSPACE_DIR_COUNT_FAIL expected=1024 actual=$(ls "$WS/small" | wc -l)"
  exit 2
fi

run_start=$(date +%s)
timeout 1800 "$BIN" run --root "$WS" --output "$OUT/run" \
  --files 1000000 --hot-files 1024 --workers 8 \
  --read-ops 8192 --cow-files 256 --write-ops 256 --mixed-ops 1024 \
  --seed 9173 --workspace 1 > "$OUT/run.out" 2>&1 &
pid=$!
run_peak=0
while kill -0 "$pid" 2>/dev/null; do
  sample=$(rss_mb)
  [ "${sample:-0}" -gt "$run_peak" ] && run_peak=$sample
  sleep 0.25
done
wait "$pid"
run_rc=$?
run_end=$(date +%s)
if [ "$run_rc" != 0 ] || [ ! -s "$OUT/run/result.json" ]; then
  log "RUN_FAIL rc=$run_rc rss_peak_mb=$run_peak output=$(tail -1 "$OUT/run.out" 2>/dev/null)"
  exit 3
fi
log "RUN_PASS wall_seconds=$((run_end - run_start)) rss_peak_mb=$run_peak"

mount_fresh before-verify-touched || exit 4

timeout 600 "$BIN" verify-touched --root "$WS" --output "$OUT/verify" \
  --state "$OUT/run/expected-touched.tsv" > "$OUT/verify.out" 2>&1
verify_rc=$?
if [ "$verify_rc" != 0 ]; then
  log "VERIFY_TOUCHED_CHILD_FAIL rc=$verify_rc output=$(tail -1 "$OUT/verify.out" 2>/dev/null)"
  exit 5
fi
log "VERIFY_TOUCHED_CHILD_PASS $(cat "$OUT/verify/result.json")"

timeout 600 "$BIN" verify-touched --root "$BASE" --output "$OUT/base" \
  --state "$OUT/run/expected-touched.tsv" --expect-base 1 > "$OUT/base.out" 2>&1
base_rc=$?
if [ "$base_rc" != 0 ]; then
  log "VERIFY_TOUCHED_BASE_FAIL rc=$base_rc output=$(tail -1 "$OUT/base.out" 2>/dev/null)"
  exit 6
fi
log "VERIFY_TOUCHED_BASE_PASS $(cat "$OUT/base/result.json")"

python3 - "$OUT" "$run_peak" > "$OUT/pilot-summary.json" <<'PY'
import json
import os
import sys

out, peak = sys.argv[1], int(sys.argv[2])
run = json.load(open(os.path.join(out, "run", "result.json")))
verify = json.load(open(os.path.join(out, "verify", "result.json")))
base = json.load(open(os.path.join(out, "base", "result.json")))
summary = {
    "completed": True,
    "passed": bool(run.get("passed") and verify.get("passed") and base.get("passed")),
    "pilot_wall_seconds": run.get("wall_seconds"),
    "run": run,
    "verify_touched_child": verify,
    "verify_touched_base": base,
    "brewfs_rss_peak_mb": peak,
}
print(json.dumps(summary))
PY
log "PILOT_DONE $(cat "$OUT/pilot-summary.json")"
