#!/usr/bin/env bash
# Reliable, resumable BrewFS C3 small-file importer.
# Progress is represented only by the presence of DONE/dXXXX marker files.
set -u -o pipefail

SRC=/srv/ax-data/c3/source/small
DEST=/mnt/brewfs-c3/base
DATA_DEST=$DEST/small
DONE=/srv/ax-data/c3/done
LOG=/srv/ax-data/c3/import-brew-final.log
CSV=/srv/ax-data/c3/import-brew-final.csv
CP_ERR=/srv/ax-data/c3/import-brew-final.err
MOUNT_LOG=/srv/ax-data/c3/mount.log
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)
CHUNK=${CHUNK:-128}
JOBS=${JOBS:-8}
MIN_CHUNK=${MIN_CHUNK:-16}
COPY_RETRIES=3
REMOUNT_RETRIES=3

mkdir -p "$DONE"
# Keep this log across resumptions; older import evidence is in separate files.
exec >>"$LOG" 2>&1

now() { date -u +%FT%TZ; }
log() { printf '[%s] %s\n' "$(now)" "$*"; }

# Count only d* markers.  This is an O(1) existence check per source directory
# in the batch loop; no per-directory find is used.
count_done() {
  local n=0 p
  local -a a=()
  shopt -s nullglob
  a=("$DONE"/d*)
  shopt -u nullglob
  for p in "${a[@]}"; do
    [ -e "$p" ] && n=$((n + 1))
  done
  printf '%d\n' "$n"
}

count_base_dirs() {
  local n=0 p
  local -a a=()
  shopt -s nullglob
  a=("$DATA_DEST"/d*)
  shopt -u nullglob
  for p in "${a[@]}"; do
    [ -d "$p" ] && n=$((n + 1))
  done
  printf '%d\n' "$n"
}

mount_pid() {
  pgrep -f 'brewfs-patched mount' | head -n 1 || true
}

rss_mb() {
  local p=${1:-}
  [ -n "$p" ] || { printf '0\n'; return; }
  [ -r "/proc/$p/status" ] || { printf '0\n'; return; }
  awk '/^VmRSS:/ { printf "%d", $2 / 1024; found=1 } END { if (!found) print 0; else print "" }' "/proc/$p/status" 2>/dev/null || printf '0\n'
}

# The complete dead-mount cleanup sequence.  It is intentionally repeated for
# every remount attempt so a failed attempt cannot leave a stale endpoint.
cleanup_mount() {
  log "cleanup: killing BrewFS mount processes"
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  local i pids
  for i in $(seq 1 20); do
    pids=$(pgrep -f 'brewfs-patched mount' || true)
    [ -z "$pids" ] && break
    sleep 1
  done
  pids=$(pgrep -f 'brewfs-patched mount' || true)
  if [ -n "$pids" ]; then
    log "cleanup failed: mount PIDs remain: $pids"
    return 1
  fi
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! ls "$DEST" >/dev/null 2>&1; then
    rm -rf "$DEST" 2>/dev/null || true
  fi
  mkdir -p "$DEST"
  [ -d "$DEST" ] || { log "cleanup failed: cannot create $DEST"; return 1; }
  return 0
}

start_mount() {
  setsid env AWS_ACCESS_KEY_ID="$AK" \
    AWS_SECRET_ACCESS_KEY="$SK" \
    AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" \
    </dev/null >>"$MOUNT_LOG" 2>&1 &
  local launcher=$! i p
  for i in $(seq 1 60); do
    if mountpoint -q "$DEST"; then
      p=$(mount_pid)
      if [ -n "$p" ]; then
        log "mount ready pid=$p"
        MOUNT_PID_RESULT=$p
        return 0
      fi
    fi
    sleep 1
  done
  log "mount did not become ready"
  return 1
}

# Set MOUNT_PID_RESULT on success.  old_pid is checked so each batch proves
# that a fresh BrewFS process replaced the one which accumulated memory.
restart_mount() {
  local old_pid=${1:-} attempt new_pid
  MOUNT_PID_RESULT=
  for attempt in $(seq 1 "$REMOUNT_RETRIES"); do
    log "remount attempt=$attempt old_pid=${old_pid:-none}"
    if cleanup_mount && start_mount; then
      new_pid=${MOUNT_PID_RESULT:-}
      if [ -n "$new_pid" ] && { [ -z "$old_pid" ] || [ "$new_pid" != "$old_pid" ]; }; then
        log "remount ok pid=$old_pid->$new_pid"
        MOUNT_PID_RESULT=$new_pid
        return 0
      fi
      log "remount rejected: PID did not change (${old_pid:-none} -> ${new_pid:-none})"
    else
      log "remount attempt=$attempt failed during cleanup/start"
    fi
  done
  log "remount failed after $REMOUNT_RETRIES attempts"
  return 1
}

ensure_initial_mount() {
  local p
  if mountpoint -q "$DEST"; then
    p=$(mount_pid)
    if [ -n "$p" ]; then
      log "using existing mount pid=$p"
      return 0
    fi
  fi
  restart_mount "" || return 1
}

copy_one() {
  local d=$1 attempt
  [ -e "$DONE/$d" ] && return 0
  for attempt in $(seq 1 "$COPY_RETRIES"); do
    if cp -a "$SRC/$d" "$DATA_DEST/" >>"$CP_ERR" 2>&1; then
      : >"$DONE/$d"
      return 0
    fi
    log "copy failed dir=$d attempt=$attempt/$COPY_RETRIES"
    sleep 1
  done
  log "copy permanently failed dir=$d"
  return 1
}

# Capture the count at the beginning so the final txn-drop value belongs to
# this run even though mount.log is intentionally append-only evidence.
TXN_START=$(grep -c 'Dropping an active transaction' "$MOUNT_LOG" 2>/dev/null || true)
TXN_START=${TXN_START:-0}
START_ALL=$(date +%s)
RUN_START=$(now)
printf "RUN %s start\n" "$RUN_START" >>"$CP_ERR"
if [ ! -s "$CSV" ]; then
  echo 'chunk,done_before,done_after,copied,elapsed_s,rss_mb,pid_before,pid_after,ok' >"$CSV"
fi

# Validate the configured range without touching any unrelated filesystem.
if [ "$CHUNK" -lt 1 ]; then CHUNK=128; fi
if [ "$JOBS" -lt 1 ]; then JOBS=1; fi
if [ "$MIN_CHUNK" -lt 1 ]; then MIN_CHUNK=1; fi
mapfile -t ALL < <(printf '%s\n' "$SRC"/d* | sed 's#^.*/##' | sort)
TOTAL=${#ALL[@]}
if [ "$TOTAL" -lt 1 ] || [ "${ALL[0]}" = 'd*' ]; then
  log "IMPORT_FINAL_FAILED no source directories"
  exit 1
fi
log "IMPORT_FINAL_START start=$RUN_START total=$TOTAL chunk=$CHUNK jobs=$JOBS min_chunk=$MIN_CHUNK"
ensure_initial_mount || { log 'IMPORT_FINAL_FAILED initial mount'; exit 1; }
mkdir -p "$DATA_DEST" || { log 'IMPORT_FINAL_FAILED data namespace'; exit 1; }

chunk_no=0
idx=0
failed_batches=0
while [ "$idx" -lt "$TOTAL" ]; do
  chunk_no=$((chunk_no + 1))
  end=$((idx + CHUNK))
  [ "$end" -gt "$TOTAL" ] && end=$TOTAL
  todo=()
  for ((j=idx; j<end; j++)); do
    d=${ALL[j]}
    [ -e "$DONE/$d" ] || todo+=("$d")
  done
  done_before=$(count_done)
  pid_before=$(mount_pid)
  if [ -z "$pid_before" ] || ! mountpoint -q "$DEST"; then
    log "batch=$chunk_no mount missing before copy; recovering"
    restart_mount "" || { log "batch=$chunk_no cannot recover mount"; exit 1; }
    pid_before=${MOUNT_PID_RESULT:-$(mount_pid)}
  fi
  batch_start=$(date +%s)
  if [ "${#todo[@]}" -eq 0 ]; then
    done_after=$(count_done)
    rss=$(rss_mb "$pid_before")
    elapsed=0
    printf '%s,%s,%s,0,%s,%s,%s,%s,1\n' "$chunk_no" "$done_before" "$done_after" "$elapsed" "$rss" "$pid_before" "$pid_before" >>"$CSV"
    log "batch=$chunk_no skip all done=$done_after pid=$pid_before rss_mb=$rss"
    idx=$end
    continue
  fi

  log "batch=$chunk_no begin range=$idx..$((end - 1)) todo=${#todo[@]} chunk_size=$CHUNK done_before=$done_before pid=$pid_before"
  failed=0
  pids=()
  for d in "${todo[@]}"; do
    copy_one "$d" &
    pids+=("$!")
    if [ "${#pids[@]}" -ge "$JOBS" ]; then
      for p in "${pids[@]}"; do wait "$p" || failed=1; done
      pids=()
    fi
  done
  for p in "${pids[@]}"; do wait "$p" || failed=1; done

  batch_end=$(date +%s)
  elapsed=$((batch_end - batch_start))
  done_after=$(count_done)
  copied=$((done_after - done_before))
  rss=$(rss_mb "$pid_before")
  ok=1
  [ "$failed" -ne 0 ] && ok=0
  if [ "$failed" -ne 0 ]; then
    failed_batches=$((failed_batches + 1))
    log "batch=$chunk_no copy failures after $COPY_RETRIES retries"
  fi

  pid_after=
  if restart_mount "$pid_before"; then
    pid_after=${MOUNT_PID_RESULT:-$(mount_pid)}
  else
    ok=0
    pid_after=$(mount_pid)
    printf '%s,%s,%s,%s,%s,%s,%s,%s,0\n' "$chunk_no" "$done_before" "$done_after" "$copied" "$elapsed" "$rss" "$pid_before" "${pid_after:-}" >>"$CSV"
    log "batch=$chunk_no REMOUNT_FAILED copied=$copied done=$done_after"
    exit 1
  fi
  printf '%s,%s,%s,%s,%s,%s,%s,%s,%s\n' "$chunk_no" "$done_before" "$done_after" "$copied" "$elapsed" "$rss" "$pid_before" "$pid_after" "$ok" >>"$CSV"
  log "batch=$chunk_no end copied=$copied done=$done_after elapsed_s=$elapsed rss_mb=$rss pid=$pid_before->$pid_after ok=$ok"
  if [ "$rss" -gt 30720 ]; then
    next=$((CHUNK / 2))
    [ "$next" -lt "$MIN_CHUNK" ] && next=$MIN_CHUNK
    if [ "$next" -lt "$CHUNK" ]; then
      log "adaptive RSS ${rss}MB > 30720MB: next_chunk=$next"
      CHUNK=$next
    fi
  fi
  idx=$end
done

END_ALL=$(date +%s)
FINAL_DONE=$(count_done)
FINAL_DIRS=$(count_base_dirs)
TXN_END=$(grep -c 'Dropping an active transaction' "$MOUNT_LOG" 2>/dev/null || true)
TXN_END=${TXN_END:-0}
TXN_RUN=$((TXN_END - TXN_START))
TOTAL_ELAPSED=$((END_ALL - START_ALL))
if [ "$FINAL_DONE" -eq "$TOTAL" ] && [ "$FINAL_DIRS" -eq "$TOTAL" ] && [ "$failed_batches" -eq 0 ] && [ "$TXN_RUN" -eq 0 ]; then
  log "IMPORT_FINAL_DONE elapsed_s=$TOTAL_ELAPSED done=$FINAL_DONE base_dirs=$FINAL_DIRS txn_drop=$TXN_RUN csv=$CSV"
  exit 0
fi
log "IMPORT_FINAL_INCOMPLETE elapsed_s=$TOTAL_ELAPSED done=$FINAL_DONE/$TOTAL base_dirs=$FINAL_DIRS/$TOTAL failed_batches=$failed_batches txn_drop=$TXN_RUN"
exit 1
