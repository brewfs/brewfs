#!/bin/bash
set -u
SRC=/srv/ax-data/c3/source/small
DEST=/mnt/brewfs-c3/base
LOG=/srv/ax-data/c3/import-brew-1m.log
mkdir -p "$DEST"
echo "IMPORT_START $(date -u +%FT%TZ)" > "$LOG"
START=$(date +%s)

# 16 路：按目录前缀分片
ls "$SRC" > /tmp/brew-dirs.txt
split -n r/16 /tmp/brew-dirs.txt /tmp/brew-part.

for p in /tmp/brew-part.*; do
  (
    while read -r d; do
      [ -d "$SRC/$d" ] || continue
      cp -a "$SRC/$d" "$DEST/" 2>>/srv/ax-data/c3/import-brew-1m.err
    done < "$p"
  ) &
done
wait

END=$(date +%s)
N=$(find "$DEST" -type f 2>/dev/null | wc -l)
echo "IMPORT_DONE elapsed=$((END-START))s files=$N" >> "$LOG"
echo "IMPORT_END $(date -u +%FT%TZ) files=$N" >> "$LOG"
