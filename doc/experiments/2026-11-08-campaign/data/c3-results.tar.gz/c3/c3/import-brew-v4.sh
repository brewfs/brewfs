#!/bin/bash
set -u
SRC=/srv/ax-data/c3/source/small
DEST=/mnt/brewfs-c3/base
DONE=/srv/ax-data/c3/done
LOG=/srv/ax-data/c3/import-brew-v4.log
CSV=/srv/ax-data/c3/import-brew-v4.csv
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)
CHUNK=${CHUNK:-256}
JOBS=${JOBS:-8}
mkdir -p "$DONE"

mount_brew() {
  mountpoint -q "$DEST" && return 0
  # 清理可能的死挂载
  umount -l "$DEST" 2>/dev/null || true
  if ! ls "$DEST" >/dev/null 2>&1; then rm -rf "$DEST" 2>/dev/null || true; fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" \
    </dev/null >> /srv/ax-data/c3/brewfs-c3-v4-mount.log 2>&1 &
  for i in $(seq 1 40); do sleep 1; mountpoint -q "$DEST" && return 0; done
  return 1
}
kill_mount() {
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 20); do
    [ "$(pgrep -fc brewfs-patched || echo 0)" = "0" ] && break
    sleep 1
  done
  sleep 2
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! ls "$DEST" >/dev/null 2>&1; then rm -rf "$DEST" 2>/dev/null || true; fi
  mkdir -p "$DEST"
}

echo "chunk,done_before,done_after,copied,elapsed_s,rss_mb,pid_before,pid_after" > "$CSV"
echo "IMPORT4_START $(date -u +%FT%TZ) chunk=$CHUNK jobs=$JOBS" > "$LOG"

ALL=$(ls "$SRC" | sort)
TOTAL=${#ALL}
START_ALL=$(date +%s)
mount_brew || { echo "MOUNT_FAILED" >> "$LOG"; exit 1; }
echo "mounted ok, done=$(ls -1 $DONE | wc -l)" >> "$LOG"

IDX=0
for ((i=0; i<TOTAL; i+=CHUNK)); do
  IDX=$((IDX+1))
  BATCH=$(echo "$ALL" | sed -n "$((i+1)),$((i+CHUNK))p")
  TODO=""
  for d in $BATCH; do [ -f "$DONE/$d" ] || TODO="$TODO $d"; done
  if [ -z "$TODO" ]; then echo "chunk=$IDX skip" >> "$LOG"; continue; fi
  PID_BEFORE=$(pgrep -f 'brewfs-patched mount' | head -1)
  DONE_BEFORE=$(ls -1 "$DONE" | wc -l)
  START=$(date +%s)
  echo $TODO | tr ' ' '\n' | split -n r/$JOBS - /tmp/v4part.
  PIDS=""
  for p in /tmp/v4part.*; do
    ( while read -r d; do
        [ -n "$d" ] || continue
        cp -a "$SRC/$d" "$DEST/" 2>>/srv/ax-data/c3/import-brew-v4.err && touch "$DONE/$d"
      done < "$p" ) &
    PIDS="$PIDS $!"
  done
  wait $PIDS
  rm -f /tmp/v4part.*
  END=$(date +%s)
  DONE_AFTER=$(ls -1 "$DONE" | wc -l)
  RSS=$(ps -C brewfs-patched -o rss= --no-headers 2>/dev/null | awk '{s+=$1} END{printf "%d", s/1024}')
  kill_mount
  if ! mount_brew; then echo "REMOUNT_FAILED chunk=$IDX" >> "$LOG"; exit 1; fi
  PID_AFTER=$(pgrep -f 'brewfs-patched mount' | head -1)
  echo "$IDX,$DONE_BEFORE,$DONE_AFTER,$((DONE_AFTER-DONE_BEFORE)),$((END-START)),${RSS:-0},${PID_BEFORE:-0},${PID_AFTER:-0}" >> "$CSV"
  echo "chunk=$IDX copied=$((DONE_AFTER-DONE_BEFORE)) done=$DONE_AFTER rss=${RSS}MB elapsed=$((END-START))s pid=$PID_BEFORE->$PID_AFTER" >> "$LOG"
done
END_ALL=$(date +%s)
echo "IMPORT4_DONE elapsed=$((END_ALL-START_ALL))s done=$(ls -1 "$DONE" | wc -l) $(date -u +%FT%TZ)" >> "$LOG"
