#!/bin/bash
set -u

OUT=/srv/ax-data/c3/brew-workspace-build-20261107
WS=/mnt/brewfs-c3/base/ws-c3-20261107
BASE=/mnt/brewfs-c3/base
DEST=$BASE
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
LOG=$OUT/run.log
REMOTES=$OUT/remounts.tsv
RSS_LIMIT_MB=${RSS_LIMIT_MB:-3072}
WORKERS=${WORKERS:-4}
RESUME=${RESUME:-0}
AK=$(cat /etc/ax-c1/rustfs-access)
SK=$(cat /etc/ax-c1/rustfs-secret)
MAX_RSS=0

if ! mountpoint -q "$DEST"; then
  echo "BrewFS is not mounted at $DEST" >&2
  exit 1
fi
mkdir -p "$OUT" "$OUT/chunks" "$WS/small"
if [ "$RESUME" != 1 ]; then
  : > "$LOG"
  printf 'seq\told_pid\tnew_pid\tbaseline_rss_mb\n' > "$REMOTES"
fi

log() {
  echo "$(date -u +%FT%TZ) $*" | tee -a "$LOG"
}

rss_mb() {
  ps -C brewfs-patched -o rss= --no-headers 2>/dev/null |
    awk '{sum += $1} END {printf "%.0f", sum / 1024}'
}

mount_fresh() {
  local reason=$1 old new i
  old=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 30); do
    [ "$(pgrep -fc brewfs-patched || true)" = 0 ] && break
    sleep 1
  done
  if [ "$(pgrep -fc brewfs-patched || true)" != 0 ]; then
    log "REMOUNT_FAIL reason=$reason still_running=$(pgrep -fc brewfs-patched || true)"
    return 1
  fi
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! timeout 5 ls "$DEST" >/dev/null 2>&1; then
    timeout 30 rm -rf "$DEST" 2>/dev/null || true
  fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" \
    AWS_DEFAULT_REGION=us-east-1 nohup "$BIN" mount --privileged \
    --config "$CFG" "$DEST" </dev/null >> "$OUT/mount.log" 2>&1 &
  for i in $(seq 1 60); do
    mountpoint -q "$DEST" && break
    sleep 1
  done
  new=$(pgrep -f 'brewfs-patched mount.*brewfs-c3/base' | head -1 || true)
  if ! mountpoint -q "$DEST" || [ -z "$new" ]; then
    log "REMOUNT_FAIL reason=$reason not_mounted old=$old new=${new:-none}"
    return 1
  fi
  if [ -n "$old" ] && [ "$new" = "$old" ]; then
    log "REMOUNT_FAIL reason=$reason pid_not_changed=$new"
    return 1
  fi
  if ! timeout 30 ls "$DEST/small" >/dev/null 2>&1; then
    log "REMOUNT_FAIL reason=$reason namespace_unreadable new=$new"
    return 1
  fi
  CURRENT_PID=$new
  local base_rss
  base_rss=$(rss_mb)
  printf '%s\t%s\t%s\t%s\n' "$reason" "${old:-none}" "$new" "$base_rss" >> "$REMOTES"
  log "REMOUNT_OK reason=$reason old=${old:-none} new=$new baseline_rss_mb=$base_rss"
}

log "WORKSPACE_BUILD_START workers=$WORKERS rss_limit_mb=$RSS_LIMIT_MB resume=$RESUME"
for ((start = 0; start < 1024; start += 32)); do
  end=$((start + 32))
  [ "$end" -gt 1024 ] && end=1024
  chunk=$((start / 32 + 1))
  printf -v chunk_name 'chunk-%02d' "$chunk"
  mount_fresh "$chunk_name" || exit 2
  setsid python3 /srv/ax-data/c3/make_workspace.py --start "$start" --end "$end" \
    --workers "$WORKERS" --output "$OUT/chunks/$chunk_name.json" \
    > "$OUT/chunks/$chunk_name.log" 2>&1 &
  pid=$!
  peak=0
  while kill -0 "$pid" 2>/dev/null; do
    sample=$(rss_mb)
    [ "${sample:-0}" -gt "$peak" ] && peak=$sample
    [ "${sample:-0}" -gt "$MAX_RSS" ] && MAX_RSS=$sample
    if [ "${sample:-0}" -gt "$RSS_LIMIT_MB" ]; then
      log "RSS_LIMIT_EXCEEDED chunk=$chunk_name rss_mb=$sample limit=$RSS_LIMIT_MB"
      kill -TERM -- "-$pid" 2>/dev/null || true
      sleep 2
      kill -KILL -- "-$pid" 2>/dev/null || true
      break
    fi
    sleep 0.5
  done
  wait "$pid"
  rc=$?
  if [ "$rc" != 0 ]; then
    log "CHUNK_FAIL $chunk_name rc=$rc rss_peak_mb=$peak log=$(tail -1 "$OUT/chunks/$chunk_name.log" 2>/dev/null)"
    exit 3
  fi
  log "CHUNK_PASS $chunk_name dirs=$((end - start)) rss_peak_mb=$peak"
done

mount_fresh workspace-inventory || exit 4
python3 /srv/ax-data/c3/verify10.py --root "$WS" \
  --inventory "$OUT/workspace-inventory.json" --inventory-only >> "$LOG" 2>&1 || {
  log "WORKSPACE_INVENTORY_FAIL"
  exit 4
}

python3 /srv/ax-data/c3/break_hot_links.py > "$OUT/break-hot-links.log" 2>&1 &
pid=$!
peak=0
while kill -0 "$pid" 2>/dev/null; do
  sample=$(rss_mb)
  [ "${sample:-0}" -gt "$peak" ] && peak=$sample
  [ "${sample:-0}" -gt "$MAX_RSS" ] && MAX_RSS=$sample
  if [ "${sample:-0}" -gt "$RSS_LIMIT_MB" ]; then
    log "RSS_LIMIT_EXCEEDED break_hot_links rss_mb=$sample limit=$RSS_LIMIT_MB"
    kill -TERM -- "-$pid" 2>/dev/null || true
    sleep 2
    kill -KILL -- "-$pid" 2>/dev/null || true
    break
  fi
  sleep 0.5
done
wait "$pid"
rc=$?
if [ "$rc" != 0 ]; then
  log "BREAK_HOT_LINKS_FAIL rc=$rc rss_peak_mb=$peak"
  exit 5
fi
log "BREAK_HOT_LINKS_PASS rss_peak_mb=$peak $(tail -1 "$OUT/break-hot-links.log")"
log "WORKSPACE_BUILD_DONE max_rss_mb=$MAX_RSS"
