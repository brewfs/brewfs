#!/bin/bash
set -e
/srv/ax-data/artifacts/bin/smallfiles prepare \
  --root /srv/ax-data/c3/source \
  --output /srv/ax-data/c3/source-prepare \
  --files 1000000 --seed 9173 > /srv/ax-data/c3/prepare-source.out 2>&1
echo PREPARE_DONE >> /srv/ax-data/c3/prepare-source.out
