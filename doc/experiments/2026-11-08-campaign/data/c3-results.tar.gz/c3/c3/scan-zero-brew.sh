#!/usr/bin/env bash
set -u -o pipefail
ROOT=/mnt/brewfs-c3/base/small
OUT=/srv/ax-data/c3/brew-zero-files.tsv
LOG=/srv/ax-data/c3/scan-zero-brew.log
exec >"$LOG" 2>&1
printf 'ZERO_SCAN_START %s\n' "$(date -u +%FT%TZ)"
find "$ROOT" -type f -size 0c -printf '%p\n' | sort >"$OUT"
printf 'ZERO_SCAN_DONE %s count=%s output=%s\n' "$(date -u +%FT%TZ)" "$(wc -l <"$OUT")" "$OUT"
