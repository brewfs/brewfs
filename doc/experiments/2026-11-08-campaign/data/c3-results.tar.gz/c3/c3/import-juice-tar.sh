#!/bin/bash
set -e
echo TAR_IMPORT_START $(date -u +%FT%TZ) >> /srv/ax-data/c3/import-juice-tar.out
tar -C /srv/ax-data/c3/source -cf - . | tar -C /mnt/juicefs-c3/base -xf -
sync
/srv/ax-data/artifacts/bin/smallfiles verify-base --root /mnt/juicefs-c3/base --output /srv/ax-data/c3/juicefs-base-verify --files 1000000 >> /srv/ax-data/c3/import-juice-tar.out 2>&1
echo TAR_IMPORT_DONE $(date -u +%FT%TZ) >> /srv/ax-data/c3/import-juice-tar.out
