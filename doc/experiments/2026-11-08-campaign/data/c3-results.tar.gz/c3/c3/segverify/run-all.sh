#!/bin/bash
set -u
SEG=/srv/ax-data/c3/segverify
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access); SK=$(cat /etc/ax-c1/rustfs-secret)
DEST=/mnt/brewfs-c3/base
LOG=$SEG/run-all.log
: > "$LOG"

remount() {
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 20); do [ "$(pgrep -fc brewfs-patched || echo 0)" = "0" ] && break; sleep 1; done
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! ls "$DEST" >/dev/null 2>&1; then rm -rf "$DEST" 2>/dev/null || true; fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" </dev/null >> $SEG/mount.log 2>&1 &
  for i in $(seq 1 40); do sleep 1; mountpoint -q "$DEST" && return 0; done
  return 1
}

for f in $(ls $SEG/seg-?? | grep -v json); do
  n=$(basename "$f")
  [[ "$n" == *.json ]] && continue
  START=$(date +%s)
  python3 /root/verify_seg.py "$f" "$SEG/$n.json" 16 >> "$LOG" 2>&1
  END=$(date +%s)
  RSS=$(ps -C brewfs-patched -o rss= --no-headers 2>/dev/null | awk '{s+=$1} END{printf "%.0f", s/1024}')
  echo "segment $n done elapsed=$((END-START))s rss=${RSS}MB" >> "$LOG"
  if ! remount; then echo "REMOUNT_FAILED at $n" >> "$LOG"; exit 1; fi
done

python3 - "$SEG" <<'PY' >> "$LOG" 2>&1
import glob, json, os, sys
seg = sys.argv[1]
agg = dict(completed=True, passed=True, files=0, mismatches=0, wall_seconds=0.0, segments=[])
for p in sorted(glob.glob(os.path.join(seg, "seg-??.json"))):
    d = json.load(open(p))
    agg["files"] += d["files"]; agg["mismatches"] += d["mismatches"]
    agg["wall_seconds"] += d["wall_seconds"]
    if d["mismatches"]: agg["passed"] = False
    agg["segments"].append(dict(file=os.path.basename(p), dirs=d["dir_count"],
                                files=d["files"], mismatches=d["mismatches"],
                                wall=d["wall_seconds"]))
agg["wall_seconds"] = round(agg["wall_seconds"], 2)
json.dump(agg, open(os.path.join(seg, "verify-base-brew-segmented.json"), "w"), indent=2)
print("AGG", json.dumps({k: agg[k] for k in ("completed","passed","files","mismatches","wall_seconds")}))
PY
echo "SEGVERIFY_DONE" >> "$LOG"
