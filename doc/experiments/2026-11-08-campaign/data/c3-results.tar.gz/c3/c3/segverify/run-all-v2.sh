#!/bin/bash
set -u
SEG=/srv/ax-data/c3/segverify
CFG=/etc/ax-c1/brewfs-c3.yaml
BIN=/srv/ax-data/artifacts/bin/brewfs-patched
AK=$(cat /etc/ax-c1/rustfs-access); SK=$(cat /etc/ax-c1/rustfs-secret)
DEST=/mnt/brewfs-c3/base
LOG=$SEG/run-all-v2.log
: > "$LOG"

mount_fresh() {
  pkill -9 -f 'brewfs-patched mount' 2>/dev/null || true
  for i in $(seq 1 20); do [ "$(pgrep -fc brewfs-patched || echo 0)" = "0" ] && break; sleep 1; done
  umount -l "$DEST" 2>/dev/null || true
  sleep 1
  if ! ls "$DEST" >/dev/null 2>&1; then rm -rf "$DEST" 2>/dev/null || true; fi
  mkdir -p "$DEST"
  setsid env AWS_ACCESS_KEY_ID="$AK" AWS_SECRET_ACCESS_KEY="$SK" AWS_DEFAULT_REGION=us-east-1 \
    nohup "$BIN" mount --privileged --config "$CFG" "$DEST" </dev/null >> $SEG/mount-v2.log 2>&1 &
  for i in $(seq 1 40); do sleep 1; mountpoint -q "$DEST" && break; done
  # 健康检查：列目录 + 读一个文件（10 s 超时）
  timeout 10 ls "$DEST/small" >/dev/null 2>&1 || return 1
  f=$(ls "$DEST/small" 2>/dev/null | head -1)
  [ -n "${f:-}" ] || return 1
  timeout 10 head -c 16 "$DEST/small/$f/$(ls "$DEST/small/$f" 2>/dev/null | head -1)" >/dev/null 2>&1 || return 1
  return 0
}

echo "SEGVERIFY2_START $(date -u +%FT%TZ)" >> "$LOG"
n=0
for f in $(ls $SEG/seg-?? | grep -v '\.json$'); do
  name=$(basename "$f")
  [ -f "$SEG/$name.json" ] && { echo "skip $name (done)" >> "$LOG"; continue; }
  n=$((n+1))
  if [ $((n % 4)) -eq 1 ]; then
    ok=0
    for try in 1 2 3; do mount_fresh && { ok=1; break; }; echo "mount_retry $try failed" >> "$LOG"; sleep 5; done
    [ "$ok" = "1" ] || { echo "MOUNT_UNHEALTHY at $name" >> "$LOG"; exit 1; }
  fi
  START=$(date +%s)
  timeout 900 python3 /root/verify_seg.py "$f" "$SEG/$name.json" 16 >> "$LOG" 2>&1
  RC=$?
  END=$(date +%s)
  RSS=$(ps -C brewfs-patched -o rss= --no-headers 2>/dev/null | awk '{s+=$1} END{printf "%.0f", s/1024}')
  echo "segment $name rc=$RC elapsed=$((END-START))s rss=${RSS}MB" >> "$LOG"
done

python3 - "$SEG" <<'PY' >> "$LOG" 2>&1
import glob, json, os, sys
seg = sys.argv[1]
agg = dict(completed=True, passed=True, files=0, mismatches=0, wall_seconds=0.0, segments=[])
for p in sorted(glob.glob(os.path.join(seg, "seg-??.json"))):
    d = json.load(open(p))
    agg["files"] += d["files"]; agg["mismatches"] += d["mismatches"]; agg["wall_seconds"] += d["wall_seconds"]
    if d["mismatches"]: agg["passed"] = False
    agg["segments"].append(dict(file=os.path.basename(p), files=d["files"], mismatches=d["mismatches"], wall=d["wall_seconds"]))
agg["wall_seconds"] = round(agg["wall_seconds"], 2)
json.dump(agg, open(os.path.join(seg, "verify-base-brew-segmented.json"), "w"), indent=2)
print("AGG", json.dumps({k: agg[k] for k in ("completed","passed","files","mismatches","wall_seconds")}))
PY
echo "SEGVERIFY2_DONE $(date -u +%FT%TZ)" >> "$LOG"
