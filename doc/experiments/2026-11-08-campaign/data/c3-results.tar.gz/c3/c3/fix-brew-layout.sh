#!/usr/bin/env bash
set -u -o pipefail
DEST=/mnt/brewfs-c3/base
LOG=/srv/ax-data/c3/fix-brew-layout.log
exec >>"$LOG" 2>&1
printf 'LAYOUT_FIX_START %s\n' "$(date -u +%FT%TZ)"
mkdir -p "$DEST/small" || { echo LAYOUT_FIX_MKDIR_FAILED; exit 1; }
ok=0
skip=0
fail=0
shopt -s nullglob
paths=("$DEST"/d[0-9][0-9][0-9][0-9])
shopt -u nullglob
for path in "${paths[@]}"; do
  b=${path##*/}
  if [ -d "$DEST/small/$b" ]; then
    skip=$((skip + 1))
    continue
  fi
  if mv "$path" "$DEST/small/"; then
    ok=$((ok + 1))
  else
    fail=$((fail + 1))
    printf 'MOVE_FAILED %s\n' "$b"
  fi
done
printf 'LAYOUT_FIX_DONE %s moved=%d skipped=%d failed=%d\n' "$(date -u +%FT%TZ)" "$ok" "$skip" "$fail"
[ "$fail" -eq 0 ]
