#!/bin/bash
set -u
export PATH=/root/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
export CARGO_TARGET_DIR=/srv/ax-data/build/brewfs-target
export CARGO_BUILD_JOBS=8
export CARGO_INCREMENTAL=1
cd /srv/ax-data/src/brewfs || exit 1
echo "start $(date -u +%FT%TZ)"
cargo build --release --offline \
  --no-default-features \
  --features fuse-io-uring-runtime,workspace-overlay,native-packed-base,rustfs-ec-block-size-hint \
  --bin brewfs > /srv/ax-data/c3/build-patched.log 2>&1
RC=$?
echo "cargo_rc=$RC $(date -u +%FT%TZ)" >> /srv/ax-data/c3/build-patched.log
ls -l "$CARGO_TARGET_DIR/release/brewfs" >> /srv/ax-data/c3/build-patched.log 2>&1
echo "BUILD_DONE rc=$RC"
