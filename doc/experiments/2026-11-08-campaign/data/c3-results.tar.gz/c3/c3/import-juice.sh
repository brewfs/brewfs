#!/bin/bash
set -e
echo IMPORT_START $(date -u +%FT%TZ) >> /srv/ax-data/c3/import-juice.out
cp -a /srv/ax-data/c3/source/. /mnt/juicefs-c3/base/
sync
/srv/ax-data/artifacts/bin/smallfiles verify-base --root /mnt/juicefs-c3/base --output /srv/ax-data/c3/juicefs-base-verify --files 1000000 >> /srv/ax-data/c3/import-juice.out 2>&1
echo IMPORT_DONE $(date -u +%FT%TZ) >> /srv/ax-data/c3/import-juice.out
