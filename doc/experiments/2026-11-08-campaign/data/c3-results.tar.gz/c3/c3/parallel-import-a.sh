#!/bin/bash
set -e
rm -rf /tmp/c3-parts-a; mkdir -p /tmp/c3-parts-a
find /srv/ax-data/c3/source/small -mindepth 1 -maxdepth 1 -type d -printf 'small/%f\n' | sort | awk '{print > ("/tmp/c3-parts-a/part-" (NR%16))}'
for p in /tmp/c3-parts-a/part-*; do
  (tar -C /srv/ax-data/c3/source -cf - -T "$p" | tar -C /mnt/juicefs-c3/base-par -xf -) &
done
wait
sync
echo PARALLEL_IMPORT_DONE >> /srv/ax-data/c3/parallel-import-a.log
