#!/bin/bash
set -e
BIN=/srv/ax-data/artifacts/bin/smallfiles
JFS=/srv/ax-data/artifacts/bin/juicefs
BASE=/mnt/juicefs-c3/base-par
WS=/mnt/juicefs-c3/ws-1
OUT=/srv/ax-data/c3/pilot-juice
rm -rf "$WS" "$OUT"
mkdir -p "$OUT"
# Metadata-only clone; data blocks remain shared with the immutable base.
"$JFS" clone --threads 16 "$BASE" "$WS"
"$BIN" run --root "$WS" --output "$OUT/run" \
  --files 1000000 --hot-files 1024 --workers 8 \
  --read-ops 8192 --cow-files 256 --write-ops 256 --mixed-ops 1024 \
  --seed 9173 --workspace 1 > "$OUT/run.out" 2>&1
"$BIN" verify-touched --root "$WS" --output "$OUT/verify" \
  --state "$OUT/run/expected-touched.tsv" > "$OUT/verify.out" 2>&1
"$BIN" verify-touched --root "$BASE" --output "$OUT/base" \
  --state "$OUT/run/expected-touched.tsv" --expect-base 1 > "$OUT/base.out" 2>&1
echo C3_JUICe_PILOT_DONE >> "$OUT/run.out"
