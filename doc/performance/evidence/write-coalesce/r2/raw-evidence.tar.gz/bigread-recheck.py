#!/usr/bin/env python3
"""One additional off/on bigread guard after the three-pair seqread follow-up."""
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

root = pathlib.Path('/home/hxy/perf-write-coalesce-r2-20261102')
sys.path.insert(0, str(root / 'harness'))
import campaign

for pair, order in enumerate([['off', 'on']], 1):
    for arm in order:
        campaign.reset()
        label = f'bigread-recheck/pair-{pair:02d}-{arm}'
        destination = root / 'broad' / label
        destination.mkdir(parents=True, exist_ok=False)
        env = dict(os.environ, BREWFS_WRITE_COALESCE_BYTES='0' if arm == 'off' else '65536', COALESCE_GUARD_ARM=label)
        command = ['docker', 'compose', '-f', str(root / 'harness/broad-compose.yml'),
                   'run', '--rm', '--no-deps', '-e', 'PERF_TOOLS=fio-bigread', 'perf']
        started = time.time()
        print(datetime.datetime.now(datetime.timezone.utc).isoformat(), 'START', label, flush=True)
        with (destination / 'runner-console.log').open('w') as output:
            result = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT)
        # Inspect object layout after the runner has unmounted, outside every
        # measured window. This distinguishes a layout change from read noise.
        objects = []
        for page in campaign.s3.get_paginator('list_objects_v2').paginate(Bucket=campaign.h.BUCKET):
            objects.extend({'key': item['Key'], 'bytes': item['Size']} for item in page.get('Contents', []))
        (destination / 'objects-after.json').write_text(json.dumps({
            'objects': objects,
            'coalesced_objects': sum('chunks-coalesced-v1/' in item['key'] for item in objects),
            'total_objects': len(objects),
        }, indent=2) + '\n')
        (destination / 'status.json').write_text(json.dumps({
            'status': result.returncode, 'pair': pair, 'arm': arm, 'command': command,
            'started': started, 'finished': time.time(),
            'binary_sha256': hashlib.sha256((root / 'bin/brewfs-candidate').read_bytes()).hexdigest(),
        }, indent=2) + '\n')
        print(datetime.datetime.now(datetime.timezone.utc).isoformat(), 'DONE', label, 'status', result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError(f'{label} failed')
campaign.reset()
