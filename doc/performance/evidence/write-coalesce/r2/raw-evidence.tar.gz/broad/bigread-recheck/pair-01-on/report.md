# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-bigread | pass | 127 | tools/fio-bigread.log |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-bigread-prefill | write | 0 | 4m | 8 | 0.00 B/s | 0.00 | 49.15 MiB/s | 12.29 | 0.000 ms | 17112.760 ms | results/fio-bigread-prefill.json |
| fio-bigread | read | 0 | 4m | 8 | 32.42 MiB/s | 8.10 | 0.00 B/s | 0.00 | 17112.760 ms | 0.000 ms | results/fio-bigread.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigread-prefill | 0 | 0 s | 665.426 s | +0.000 s | - | 83.329 s | +0.000 s | - | - |
| fio-bigread | 0 | 127 s | 1009.181 s | -882.181 s | 0.13x | 126.358 s | +0.642 s | 1.01x | fio job_runtime aggregates jobs |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigread | 0.000 ms | 0.000 ms | 0.000 ms | 17112.760 ms | 0.000 ms | 0.000 ms | 17112.760 ms | 17112.760 ms | 17112.760 ms |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigread-prefill | 0.000 ms | 0.000 ms | 0.000 ms | 17112.760 ms | 0.000 ms | 0.000 ms | 17112.760 ms | 17112.760 ms | 17112.760 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-bigread | evalsha: calls=93, usec/call=60.47<br>exec: calls=88, usec/call=19.84<br>get: calls=97, usec/call=6.93<br>lrange: calls=88, usec/call=7.60<br>hget: calls=91, usec/call=6.16 | diagnostics/redis-fio-bigread-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigread | 0.0% (0/24692) | 4096.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=9381, PUT=0 | GET=99.10 ms, PUT=0.00 ms | diagnostics/stats-fio-bigread-after.txt; range=0, full=8308, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=69, max_buffer_dirty=0.0 MiB, max_live_dirty=0.0 MiB, max_live_slices=0, max_recent_pending=0.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=0.0 MiB, max_remote_inflight=0.0 MiB, last_buffer_dirty=0.0 MiB, slices=create 0/reuse 0/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 0/auto 0/max 0/age 0 |
| fio-bigread-prefill | 0.0% (0/0) | 0.0 MiB | 4096.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=1073 | GET=2.65 ms, PUT=1420.28 ms | diagnostics/stats-fio-bigread-prefill-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 337.42s, flush_wait=8 ops/14.02s/11 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=19, max_buffer_dirty=264.0 MiB, max_live_dirty=264.0 MiB, max_live_slices=19, max_recent_pending=0.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=0.0 MiB, max_remote_inflight=166.0 MiB, last_buffer_dirty=204.0 MiB, slices=create 229/reuse 3868/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=228 avg=18.0 MiB blocks=4.71/batch partial_tail=0.44 (size 18/max 0/flush 0/auto 82/age 0), partial_origin=normal 100/cached 0/mixed 0/unknown 0, auto_detail=age 72/idle 10/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 82/cached 0/mixed 0/unknown 0, freeze=size 90/flush 1/auto 138/max 0/age 0 |
| fio-bigread-prefill-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=0 | GET=2.65 ms, PUT=1418.97 ms | diagnostics/stats-fio-bigread-prefill-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 229/reuse 3868/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 90/flush 1/auto 138/max 0/age 0 |
| fio-bigread-prefill-runner-drained | 0.0% (0/1) | 0.0 MiB | 4096.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=1, PUT=1074 | GET=2.65 ms, PUT=1418.97 ms | diagnostics/stats-fio-bigread-prefill-runner-drained-after.txt; range=1, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 337.42s, flush_wait=9 ops/14.03s/12 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 229/reuse 3868/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=229 avg=17.9 MiB blocks=4.69/batch partial_tail=0.44 (size 18/max 0/flush 1/auto 82/age 0), partial_origin=normal 101/cached 0/mixed 0/unknown 0, auto_detail=age 72/idle 10/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 82/cached 0/mixed 0/unknown 0, freeze=size 90/flush 1/auto 138/max 0/age 0 |

## FUSE Op Trace

- brewfs_fuse_ops.log: 50,804 lines

## Bottleneck Analysis

- **fio-bigread-prefill**: Write P99=17113ms > 500ms — inspect writeback samples and tune upload queue depth, slice age, or write buffer.
- **fio-bigread**: Read p50=17113ms — network RTT dominates. Consider local SSD cache or prefetch tuning.
