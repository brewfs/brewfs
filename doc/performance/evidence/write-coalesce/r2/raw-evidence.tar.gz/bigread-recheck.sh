#!/usr/bin/env bash
set -euo pipefail
r2_artifact=/home/hxy/perf-write-coalesce-r2-20261102
while [[ ! -f "$r2_artifact/seqread-recheck.finished" ]]; do sleep 15; done
[[ $(cat "$r2_artifact/seqread-recheck.status") == 0 ]]
python3 "$r2_artifact/summarize-seqread-recheck.py" > "$r2_artifact/seqread-recheck-summary.log"
if ! python3 -c 'import json,sys; sys.exit(not json.load(open(sys.argv[1]))["accepted"])' "$r2_artifact/seqread-recheck-summary.json"; then
    printf '%s\n' 'seqread follow-up blocked acceptance; no bigread guard scheduled' > "$r2_artifact/bigread-recheck.not-started"
    exit 1
fi
date -u +%FT%TZ > "$r2_artifact/bigread-recheck.started"
r2_status=0
sudo -n python3 "$r2_artifact/bigread-recheck.py" > "$r2_artifact/bigread-recheck.log" 2>&1 || r2_status=$?
printf '%s\n' "$r2_status" > "$r2_artifact/bigread-recheck.status"
date -u +%FT%TZ > "$r2_artifact/bigread-recheck.finished"
exit "$r2_status"
