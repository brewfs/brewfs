#!/usr/bin/env python3
"""Issue 391 baseline probes; calls the mounted POSIX filesystem only."""
import argparse
import ctypes
import hashlib
import json
import mmap
import os
from pathlib import Path
import random
import time

parser = argparse.ArgumentParser()
parser.add_argument("kind", choices=("single", "aggregate"))
parser.add_argument("root", type=Path)
parser.add_argument("--direct", type=int, required=True)
parser.add_argument("--count", type=int, default=256)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--verify-only", action="store_true")
args = parser.parse_args()
if args.verify_only:
    assert args.root.is_dir(), "recovered directory is missing"
else:
    args.root.mkdir(parents=True, exist_ok=True)
libc = ctypes.CDLL(None, use_errno=True)
libc.pwrite.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_longlong]
libc.pwrite.restype = ctypes.c_ssize_t
buffer = mmap.mmap(-1, 4096)
address = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
flags = os.O_CREAT | os.O_RDWR | (os.O_DIRECT if args.direct else 0)
rng = random.Random(391)
expected = {}
started = time.monotonic()

def write(fd, offset, payload):
    buffer[:] = payload
    n = libc.pwrite(fd, address, 4096, offset)
    if n != 4096:
        raise OSError(ctypes.get_errno(), f"short pwrite: {n}")

if args.kind == "single":
    for i in range(args.count):
        payload = rng.randbytes(4096)
        path = args.root / f"file-{i:06}"
        if not args.verify_only:
            fd = os.open(path, flags, 0o600)
            try:
                write(fd, 0, payload)
                os.fsync(fd)
            finally:
                os.close(fd)
        expected[str(path)] = hashlib.sha256(payload).hexdigest()
    for path, digest in expected.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
else:
    path = args.root / "sparse"
    fd = None if args.verify_only else os.open(path, flags, 0o600)
    try:
        for i in range(args.count):
            page = i * 4051 % args.count
            offset = page * 65536
            payload = rng.randbytes(4096)
            if fd is not None:
                write(fd, offset, payload)
            expected[offset] = hashlib.sha256(payload).hexdigest()
            if fd is not None and (i + 1) % 256 == 0:
                os.fsync(fd)
        if fd is not None:
            os.fsync(fd)
    finally:
        if fd is not None:
            os.close(fd)
    fd = os.open(path, os.O_RDONLY)
    try:
        for offset, digest in expected.items():
            assert hashlib.sha256(os.pread(fd, 4096, offset)).hexdigest() == digest
            hole_size = min(61440, max(0, os.fstat(fd).st_size-offset-4096))
            if hole_size:
                assert os.pread(fd, hole_size, offset+4096) == bytes(hole_size), f"nonzero hole after {offset}"
    finally:
        os.close(fd)
result = dict(kind=args.kind, direct=args.direct, logical_bytes=args.count * 4096,
              count=args.count, verified=len(expected), verify_only=args.verify_only,
              hashes_sha256=hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest(),
              seconds=time.monotonic()-started)
args.output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
