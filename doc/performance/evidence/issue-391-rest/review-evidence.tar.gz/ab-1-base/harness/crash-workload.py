#!/usr/bin/env python3
"""Verify every acknowledged fsync prefix across mount-process death."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
import hashlib
import json
import mmap
import os
from pathlib import Path
import time

p = argparse.ArgumentParser()
p.add_argument('phase', choices=('write','verify'))
p.add_argument('root', type=Path)
p.add_argument('--manifest', type=Path, required=True)
p.add_argument('--direct', type=int, default=1)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
libc = ctypes.CDLL(None, use_errno=True)
libc.pwrite.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_longlong]
libc.pwrite.restype = ctypes.c_ssize_t

def payload(job, page):
    return hashlib.sha256(f'391:{job}:{page}'.encode()).digest()*128

def writer(job):
    fd = os.open(a.root / f'job-{job}', os.O_CREAT|os.O_RDWR|(os.O_DIRECT if a.direct else 0), 0o600)
    buffer = mmap.mmap(-1,4096)
    address = ctypes.addressof(ctypes.c_char.from_buffer(buffer))
    journal = os.open(a.manifest, os.O_WRONLY|os.O_CREAT|os.O_APPEND, 0o600)
    pages = 0
    try:
        for page in range(65536):
            buffer[:] = payload(job,page)
            count = libc.pwrite(fd,address,4096,page*65536)
            if count != 4096:
                raise OSError(ctypes.get_errno(),f'short write {count}')
            pages = page+1
            if pages % 256 == 0:
                os.fsync(fd)
                record = (json.dumps(dict(job=job,pages=pages,wall_ns=time.time_ns()))+'\n').encode()
                assert os.write(journal,record) == len(record)
                os.fsync(journal)
    except OSError as error:
        return dict(job=job,stopped_after_pages=pages,error=str(error),errno=error.errno,wall_ns=time.time_ns())
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        os.close(journal)

if a.phase == 'write':
    a.root.mkdir(parents=True,exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(writer,range(4)))
    a.output.write_text(json.dumps(results,indent=2)+'\n')
else:
    acknowledged = {}
    for line in a.manifest.read_text().splitlines():
        row = json.loads(line)
        acknowledged[row['job']] = max(acknowledged.get(row['job'],0),row['pages'])
    assert len(acknowledged) == 4
    verified = 0
    for job,pages in acknowledged.items():
        fd = os.open(a.root/f'job-{job}',os.O_RDONLY)
        try:
            assert os.fstat(fd).st_size >= (pages-1)*65536+4096
            for page in range(pages):
                assert os.pread(fd,4096,page*65536) == payload(job,page),f'job {job} page {page}'
                if page+1 < pages:
                    assert os.pread(fd,61440,page*65536+4096) == bytes(61440)
                verified += 1
        finally:
            os.close(fd)
    result = dict(acknowledged_pages=acknowledged,verified_pages=verified,verified_bytes=verified*4096)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
