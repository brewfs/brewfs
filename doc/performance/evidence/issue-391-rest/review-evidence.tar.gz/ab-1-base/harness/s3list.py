#!/usr/bin/env python3
"""Record exact S3 stored object lengths independently of client metrics."""
import datetime
import hashlib
import hmac
import json
import os
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

endpoint = os.environ.get("BREWFS_S3_ENDPOINT", "http://rustfs:9000")
bucket = os.environ.get("BREWFS_S3_BUCKET", "brewfs-data")
access = os.environ.get("AWS_ACCESS_KEY_ID", "rustfsadmin")
secret = os.environ.get("AWS_SECRET_ACCESS_KEY", "rustfsadmin")
region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
host = urllib.parse.urlparse(endpoint).netloc
objects = []
token = None
while True:
    now = datetime.datetime.now(datetime.timezone.utc)
    stamp, day = now.strftime("%Y%m%dT%H%M%SZ"), now.strftime("%Y%m%d")
    params = {"list-type": "2", "max-keys": "1000"}
    if token:
        params["continuation-token"] = token
    query = urllib.parse.urlencode(sorted(params.items()), quote_via=urllib.parse.quote)
    empty = hashlib.sha256(b"").hexdigest()
    headers = f"host:{host}\nx-amz-content-sha256:{empty}\nx-amz-date:{stamp}\n"
    signed = "host;x-amz-content-sha256;x-amz-date"
    uri = "/" + bucket
    canonical = f"GET\n{uri}\n{query}\n{headers}\n{signed}\n{empty}"
    scope = f"{day}/{region}/s3/aws4_request"
    string = f"AWS4-HMAC-SHA256\n{stamp}\n{scope}\n{hashlib.sha256(canonical.encode()).hexdigest()}"
    key = ("AWS4" + secret).encode()
    for value in [day, region, "s3", "aws4_request"]:
        key = hmac.new(key, value.encode(), hashlib.sha256).digest()
    sig = hmac.new(key, string.encode(), hashlib.sha256).hexdigest()
    authorization = f"AWS4-HMAC-SHA256 Credential={access}/{scope}, SignedHeaders={signed}, Signature={sig}"
    req = urllib.request.Request(endpoint + uri + "?" + query, headers={
        "x-amz-date": stamp, "x-amz-content-sha256": empty, "Authorization": authorization})
    body = urllib.request.urlopen(req).read()
    root = ET.fromstring(body)
    ns = {"s": root.tag.partition("}")[0].lstrip("{")}
    for row in root.findall("s:Contents", ns):
        objects.append({"key": row.findtext("s:Key", namespaces=ns),
                        "size": int(row.findtext("s:Size", namespaces=ns))})
    token = root.findtext("s:NextContinuationToken", namespaces=ns)
    if not token:
        break
Path(sys.argv[1]).write_text(json.dumps(dict(objects=objects, count=len(objects),
    bytes=sum(x["size"] for x in objects)), indent=2) + "\n")
