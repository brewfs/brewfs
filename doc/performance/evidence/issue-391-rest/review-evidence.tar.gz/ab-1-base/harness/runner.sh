#!/usr/bin/env bash
set -euo pipefail
source <(sed '$d' /usr/local/bin/run_perf_in_container.sh)
eval "$(declare -f run_perf_suite | sed '1s/run_perf_suite/standard_run_perf_suite/')"

eval "$(declare -f initialize_workspace_volume | sed '1s/initialize_workspace_volume/standard_initialize_workspace_volume/')"
initialize_workspace_volume() {
    if [[ "${ISSUE391_PACKED:-0}" == 1 && -z "${BREWFS_WORKSPACE_ID:-}" ]]; then
        mkdir -p /var/lib/brewfs/seed/.perf-fio-randwrite
        python3 - <<'PY'
from pathlib import Path
import hashlib
import json
import os
pattern = bytes(range(256)) * 4096
hashes = {}
for job in range(4):
    path = Path('/var/lib/brewfs/seed/.perf-fio-randwrite') / f'r.{job}'
    digest = hashlib.sha256()
    with path.open('wb') as stream:
        for _ in range(512):
            stream.write(pattern)
            digest.update(pattern)
        stream.flush()
        os.fsync(stream.fileno())
    hashes[path.name] = digest.hexdigest()
Path('/artifacts/seed-sha256.json').write_text(json.dumps(hashes, indent=2)+'\n')
PY
        /usr/local/bin/packed_v3_snapshot_fixture \
            --source-directory /var/lib/brewfs/seed \
            --source-consistency best-effort-detected --source-hardlink-policy visible-links \
            --bucket "$BREWFS_S3_BUCKET" --endpoint "$BREWFS_S3_ENDPOINT" --region "$BREWFS_S3_REGION" \
            --force-path-style true --prefix issue391-lower --frame-policy static-4mib \
            --max-random-frame-raw-bytes 4194304 \
            --data-codec raw --metadata-codec raw --inline-data off \
            --manifest-output /var/lib/brewfs/manifest-key.txt \
            >"$artifact_dir/packed-fixture.log" 2>&1 || return $?
        workspace_cli init-packed-volume --owner issue391 \
            --manifest-key "$(tr -d '[:space:]' </var/lib/brewfs/manifest-key.txt)" \
            --data-config "$config_path" >"$artifact_dir/packed-init.raw" 2>&1 || return $?
        workspace_json_body "$artifact_dir/packed-init.raw" >"$artifact_dir/packed-init.json"
        BREWFS_WORKSPACE_ID="$(workspace_id_from_json "$artifact_dir/packed-init.json")"
        export BREWFS_WORKSPACE_ID
    elif [[ ( "${BREWFS_VOLUME_FORMAT:-}" == workspace-v1 || "${BREWFS_VOLUME_FORMAT:-}" == workspace-native-v2 ) && -z "${BREWFS_WORKSPACE_ID:-}" ]]; then
        workspace_cli init-volume --owner issue391 --data-config "$config_path" \
            >"$artifact_dir/issue391-workspace-init.raw" 2>&1 || return $?
        workspace_json_body "$artifact_dir/issue391-workspace-init.raw" >"$artifact_dir/issue391-workspace-init.json"
        BREWFS_WORKSPACE_ID="$(workspace_id_from_json "$artifact_dir/issue391-workspace-init.json")"
        export BREWFS_WORKSPACE_ID
    fi
    standard_initialize_workspace_volume
}

run_perf_suite() {
    # The repository runner drains preflight only for WS-0. A normal mount
    # can still be completing its 28-byte sanity write when counters are read.
    # Require a stable zero-debt boundary on both measurement arms.
    wait_for_strict_drain issue391-preflight preflight 180 0.5 0 issue391-preflight || return $?
    case "${ISSUE391_KIND}" in
        single|aggregate)
            local count=256
            [[ "$ISSUE391_KIND" == aggregate ]] && count=8192
            python3 /evidence/s3list.py "$artifact_dir/objects-before.json"
            run_logged_tool "$ISSUE391_KIND" python3 /evidence/workload.py \
                "$ISSUE391_KIND" "$mount_dir/issue391-$ISSUE391_KIND" \
                --count "$count" --direct "$ISSUE391_DIRECT" \
                --output "$artifact_dir/results/workload.json" || return $?
            wait_for_strict_drain "$ISSUE391_KIND" post-write 180 0.5 0 issue391 || return $?
            python3 /evidence/s3list.py "$artifact_dir/objects-after.json"
            ;;
        pressure)
            if [[ "${ISSUE391_PACKED:-0}" == 1 ]]; then
                # Preserve the immutable lower's existing directory and files.
                # The standard profile removes its work directory, and named
                # extra args currently append a second --name (a second job).
                local work_dir="$mount_dir/.perf-fio-randwrite" status=0
                for job in 0 1 2 3; do
                    [[ -f "$work_dir/r.$job" ]] || return 1
                    [[ "$(stat -c %s "$work_dir/r.$job")" == 536870912 ]] || return 1
                done
                local -a args=(--name=brewfs-randwrite --directory="$work_dir"
                    '--filename_format=r.$jobnum' --allow_file_create=0
                    --rw=randwrite --bs=4k --size=512m --numjobs=4 --ioengine=libaio
                    --iodepth=32 --direct="$ISSUE391_DIRECT" --runtime="$PERF_FIO_RUNTIME"
                    --time_based --group_reporting --eta=never)
                append_fio_observation_args args
                args+=(--output-format=json --output="$artifact_dir/results/fio-randwrite.json")
                run_logged_tool fio-randwrite run_observed_fio fio-randwrite "${args[@]}" || status=$?
                append_fio_log_summary "$artifact_dir/results/fio-randwrite.json" \
                    "$artifact_dir/tools/fio-randwrite.log" fio-randwrite || status=1
                wait_for_fio_post_write_drain fio-randwrite || status=1
                return "$status"
            else
                run_fio_profile fio-randwrite randwrite || return $?
            fi
            ;;
        regression)
            for scene in randwrite seqwrite randrw seqread randread; do
                run_fio_profile "fio-$scene" "$scene" || return $?
            done
            ;;
        broad)
            # The first failed scene already rejects the broad gate. Preserve
            # that artifact and tear down rather than repeat long failed tails.
            for scene in seqread seqwrite randread randwrite randrw bigread bigwrite; do
                run_fio_profile "fio-$scene" "$scene" || return $?
            done
            run_metaperf || return $?
            run_dirstress || return $?
            run_dirperf || return $?
            ;;
        recovery)
            python3 /evidence/crash-workload.py write "$mount_dir/recovery" \
                --manifest "$artifact_dir/acknowledged.jsonl" --direct "$ISSUE391_DIRECT" \
                --output "$artifact_dir/writer-stop.json" >"$artifact_dir/crash-writer.log" 2>&1 &
            local writer_pid=$! ready=0
            for ((attempt=0; attempt<240; attempt++)); do
                if python3 - "$artifact_dir/acknowledged.jsonl" <<'PY'
import json,sys
from pathlib import Path
path = Path(sys.argv[1])
jobs = {json.loads(line)['job'] for line in path.read_text().splitlines()} if path.exists() else set()
sys.exit(0 if len(jobs)==4 else 1)
PY
                then ready=1; break; fi
                kill -0 "$writer_pid" || break
                sleep 0.5
            done
            if (( ready != 1 )); then
                kill "$writer_pid" || true
                err "crash probe did not acknowledge a checkpoint in every job"
                return 1
            fi
            stats_snapshot_before_tool crash-at-kill
            printf '%s\n' "$(date +%s%N)" >"$artifact_dir/kill-wall-ns.txt"
            kill -KILL "$(cat /run/brewfs/perf-mount.pid)"
            wait "$writer_pid" || return $?
            fusermount3 -u "$mount_dir" || return $?
            # Lease TTL is 30 seconds; let it expire without a forced takeover.
            sleep 32
            export BREWFS_CACHE_ROOT=/var/lib/brewfs/recovery-cache
            write_config
            install_mount_helper
            mount_brewfs || return $?
            verify_workspace_lease || return $?
            run_logged_tool recovery-verify python3 /evidence/crash-workload.py verify "$mount_dir/recovery" \
                --manifest "$artifact_dir/acknowledged.jsonl" --direct "$ISSUE391_DIRECT" \
                --output "$artifact_dir/results/recovery.json" || return $?
            ;;
        *) return 2 ;;
    esac
}

main "$@"
